# ITACHI GAME SPACE (v1.3) — Android Game Space for Mobile Legends

Package `com.sanju.systemx` (upgrades the previous SANJU SYSTEM X install). Kotlin, Material 3, minSdk 26, no root. Shizuku is
required for the advanced features; without it the app opens in limited mode and says exactly what is unavailable.

## Stages (kept separate)
1. **Opening animation (4.5 s)**: red moon, ravens, feathers, hooded silhouette with glowing eyes, logo, loading bar. Tap to skip; Settings can disable it.
2. **Game Space home**: MLBB card, LAUNCH GAME, BOOST & PLAY, performance summary, shortcuts (Effects, Touch, Panel, Settings).
3. **Floating panel over the game** (Panel tab → START PANEL): bubble ⇄ panel, draggable, opacity, FPS/Hz/temp/CPU, FPS graph, TOUCH / DND / FILTER / PING / RESTORE.

## Feature table (nothing below has been tested on a phone yet)
| Feature | Method | Permission | No root | Tested on Vivo Y05 | Known limits |
|---|---|---|---|---|---|
| Opening animation, ambient background | Canvas, one animator; bg paused when hidden | none | yes | NO | Original vector art, not the reference image |
| Game detection / launch | PackageManager launcher query | none | yes | NO | |
| Display Hz detect + request | Display modes + window preferredDisplayModeId | none | yes | NO | Applies to this app's window; system may override |
| Game FPS limit 30–120 | NOT POSSIBLE | – | – | – | MLBB owns its FPS limit; options shown disabled |
| Live game FPS | SurfaceFlinger `--latency` timestamps | Shizuku | yes | NO | May be unavailable on Android 16; then shows N/A with reason |
| CPU % | `/proc/stat` via Shizuku | Shizuku | yes | NO | |
| GPU % | MediaTek GED node via Shizuku | Shizuku | yes | NO | Only if the node exists; else Unavailable |
| RAM, battery, temp, thermal status | ActivityManager, BatteryManager, PowerManager | none | yes | NO | Battery temp is not CPU temp |
| Performance modes | Android Game Mode (`cmd game mode`), refresh request, keep-awake, optional resolution | Shizuku (some) | yes | NO | Gains are NOT promised; measure yourself |
| Touch response SLOW/DEFAULT/FAST | system touch-and-hold delay | Shizuku | yes | NO | Not touch sampling rate |
| Resolution | `wm size` with confirmation + 15 s revert | Shizuku | yes | worked in v1.1 | |
| Game colour | touch-through tint/dim overlay; grayscale via Android colour correction | overlay; Shizuku for gray | yes | NO | No saturation/contrast/Vivid |
| DND | NotificationManager policy | DND access | yes | NO | Calls/alarms may still pass |
| Screenshot / screen-record shortcuts | NOT POSSIBLE for normal apps | – | – | – | Not included |

## Honest test status
Static checks only (XML valid, resources exist, brackets balanced, imports resolve). Not compiled in the authoring environment: the first
GitHub Actions run is the real build test. Performance before/after numbers must be recorded by you on the phone.

---

v1.2 opens straight into **GAME SPACE**, a landscape gaming hub: boot intro, game library, BOOST & PLAY, performance profiles,
real monitor, settings, and short original sound effects (res/raw, synthesized). The v1.1 portrait tools remain under
Game Space > Settings > LEGACY / ADVANCED TOOLS.
Honesty rules: no fake FPS/GPU/CPU numbers. External game FPS and GPU/CPU load show "Unavailable". Refresh-rate requests apply to
the Game Space window only. Resolution changes need Shizuku, show the exact command first, and can be reset.


Package `com.sanju.systemx` · Kotlin · Material 3 · minSdk 26 · no permissions · no root.

## Build the APK from your phone (GitHub Actions)
1. Open github.com in Chrome and sign in (menu ⋮ → tick "Desktop site" if buttons are missing).
2. Tap **+** (top right) → **New repository**.
3. Repository name: `SanjuSystemX`. Choose **Public**. Tap **Create repository**.
4. Tap **uploading an existing file** (or **Add file → Upload files**). Pick `SanjuSystemX.zip` from Downloads. Tap **Commit changes**.
   (The workflow unpacks the zip automatically.)
5. Tap **Add file → Create new file**. In the name box type exactly `.github/workflows/build.yml` (typing `/` creates folders).
   Paste the full contents of `build.yml` from this project. Tap **Commit changes**.
6. Tap the **Actions** tab. If asked, tap **I understand my workflows, enable them**.
7. Tap **Build APK** in the left list (or the ☰ workflow menu).
8. Tap **Run workflow** → green **Run workflow**.
9. Wait 4–8 minutes. A yellow dot becomes a green ✔.
10. Tap the finished run (top of the list).
11. Scroll to **Artifacts**.
12. Tap **SanjuSystemX-debug-apk** to download a zip, open it with Files, extract the `.apk`.
13. Tap the `.apk`. If asked, allow "Install unknown apps" for your Files/Chrome app, then tap **Install**.

## If the build fails
Open the failed run → tap the red step → copy the first lines starting with `e:` or `error:` and send them to me
with the file name and line shown. Common causes: wrong folder structure (the `app/` folder must be at the repo root),
`build.yml` not at `.github/workflows/build.yml`, or a typo when pasting.

## What is REAL
- Refresh-rate detection and switching (`preferredDisplayModeId`, this app's window only; Android may override).
- Live FPS of this app's own rendering, system RAM, app heap, battery %, battery temperature, per-core CPU frequency (when the device allows reading it).
- Device info, installed-game detection via launcher package visibility, launching a game, keep-screen-awake, clearing this app's own cache.
- Anime mode: a colour filter on this app's UI only.

## What Android does NOT allow (labelled in the app)
- Forcing a game's FPS or graphics level; system-wide resolution change (needs ADB/Shizuku); CPU/GPU load readings (not public APIs);
  modifying or filtering games. The app never injects into, patches or touches Mobile Legends.

## Shizuku (v1.1)
Resolution > Connect Shizuku: start Shizuku (Wireless debugging), tap the button, allow the app. Apply/Reset then run `wm size` only after you confirm the exact command; a 15 s keep/revert timer protects you.

## Shizuku (old notes)
The app detects whether the Shizuku app is installed and always shows "Not Connected" because this build has no Shizuku API integration.
`shizuku/ShizukuBridge.kt` contains the `PrivilegedOps` interface where future, user-confirmed operations can be added.

## Project layout
`ui/` helpers & chart · `monitor/` metrics · `optimizer/` presets/actions · `gaming/` game scan · `resolution/` display modes · `shizuku/` bridge · `settings/` prefs.
