package com.sanju.systemx.gamespace

import android.content.Context
import androidx.lifecycle.ViewModel
import com.sanju.systemx.device.GraphicsInfo
import com.sanju.systemx.device.GraphicsInfoProvider
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import kotlinx.coroutines.flow.MutableStateFlow

/** Holds Game Space state across configuration changes. Never keeps an Activity reference. */
class GameSpaceViewModel : ViewModel() {
    val games = MutableStateFlow<List<GameInfo>>(emptyList())
    val selected = MutableStateFlow("")
    val shizuku = MutableStateFlow<ShizukuState?>(null)
    val graphics = MutableStateFlow<GraphicsInfo?>(null)
    @Volatile var introDone = false
    @Volatile var healthy = true
    var lastSession: String? = null

    fun selectedGame(): GameInfo? = games.value.firstOrNull { it.pkg == selected.value }

    suspend fun load(app: Context, prefs: Prefs) {
        try {
            if (prefs.getB("autoShizuku", true)) shizuku.value = ShizukuBridge.state(app)
            val list = GameRepository.load(app, prefs)
            games.value = list
            val saved = prefs.getS("game", "")
            selected.value = list.firstOrNull { it.pkg == saved }?.pkg
                ?: list.firstOrNull { it.isMl }?.pkg ?: list.firstOrNull()?.pkg ?: ""
            graphics.value = GraphicsInfoProvider.read(app)
            GsLog.d("GameSpace", "initialized, games=${list.size}")
        } catch (e: Throwable) {
            healthy = false
            GsLog.d("GameSpace", "init failed: ${e.javaClass.simpleName}")
        }
    }
}
