package com.sanju.systemx.device

import android.app.ActivityManager
import android.content.Context
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import com.sanju.systemx.settings.GsLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GraphicsInfo(val renderer: String?, val vendor: String?, val glEs: String?, val vulkan: String?) {
    val apiSummary: String
        get() = listOfNotNull(vulkan?.let { "Vulkan $it" }, glEs?.let { "OpenGL ES $it" })
            .joinToString(" · ").ifEmpty { "Unavailable" }
    val gpuShort: String get() = renderer?.take(14)?.uppercase() ?: "N/A"
}

/** Reads the real GL renderer through a 1x1 EGL pbuffer and the supported API versions from the system. */
object GraphicsInfoProvider {
    suspend fun read(ctx: Context): GraphicsInfo = withContext(Dispatchers.IO) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val es = am.deviceConfigurationInfo.glEsVersion
        val vk = ctx.packageManager.systemAvailableFeatures
            .firstOrNull { it.name == "android.hardware.vulkan.version" }
            ?.let { "${it.version shr 22}.${(it.version shr 12) and 0x3ff}" }
        var renderer: String? = null
        var vendor: String? = null
        try {
            val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val ver = IntArray(2)
            if (EGL14.eglInitialize(dpy, ver, 0, ver, 1)) {
                val cfgs = arrayOfNulls<EGLConfig>(1)
                val n = IntArray(1)
                EGL14.eglChooseConfig(
                    dpy,
                    intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE),
                    0, cfgs, 0, 1, n, 0
                )
                val cfg = cfgs[0]
                if (cfg != null && n[0] > 0) {
                    val c = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
                    val s = EGL14.eglCreatePbufferSurface(dpy, cfg, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
                    if (EGL14.eglMakeCurrent(dpy, s, s, c)) {
                        renderer = GLES20.glGetString(GLES20.GL_RENDERER)
                        vendor = GLES20.glGetString(GLES20.GL_VENDOR)
                    }
                    EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    EGL14.eglDestroySurface(dpy, s)
                    EGL14.eglDestroyContext(dpy, c)
                }
            }
        } catch (e: Throwable) {
            GsLog.d("Graphics", "EGL query failed: ${e.javaClass.simpleName}")
        }
        GraphicsInfo(renderer, vendor, es, vk)
    }
}
