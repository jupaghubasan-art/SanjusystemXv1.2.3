package com.sanju.systemx.optimizer

import android.app.Activity
import android.os.Build
import android.view.WindowManager
import com.sanju.systemx.gamespace.GameInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.system.DndMode
import com.sanju.systemx.system.DndManager
import com.sanju.systemx.system.GameModeManager
import com.sanju.systemx.system.TouchPreset
import com.sanju.systemx.system.TouchPresets
import kotlinx.coroutines.delay
import java.util.Locale

enum class RefreshTarget { MIN, MID, MAX, DEFAULT }

/** The three real modes. Each one maps to supported actions only (see [OptimizationEngine.run]). */
enum class OptimizationProfile(
    val title: String, val refresh: RefreshTarget, val scale: Float, val awake: Boolean,
    val gameMode: String, val touch: TouchPreset, val dnd: DndMode?
) {
    BATTERY("BATTERY SAVER", RefreshTarget.MIN, 1.0f, false, "battery", TouchPreset.DEFAULT, null),
    BALANCED("BALANCED", RefreshTarget.MID, 1.0f, false, "standard", TouchPreset.DEFAULT, null),
    PERFORMANCE("PERFORMANCE", RefreshTarget.MAX, 0.8f, true, "performance", TouchPreset.FAST, DndMode.GAMING);

    fun describe(): String {
        val res = if (scale < 1f) String.format(Locale.US, "%.1fx (Shizuku)", scale) else "native"
        return "Refresh: ${refresh.name} · Resolution: $res · Game Mode: $gameMode · Touch: ${touch.title} · DND: ${dnd?.title ?: "unchanged"} · Keep awake: ${if (awake) "YES" else "NO"}"
    }

    companion object {
        fun fromName(n: String): OptimizationProfile = values().firstOrNull { it.name == n } ?: BALANCED
    }
}

enum class Kind { OK, INFO, FAIL }
data class Step(val kind: Kind, val text: String) {
    val mark: String get() = when (kind) { Kind.OK -> "✓"; Kind.INFO -> "ℹ"; Kind.FAIL -> "✕" }
}

data class OptimizationResult(val steps: List<Step>) {
    val successful get() = steps.filter { it.kind == Kind.OK }
    val informational get() = steps.filter { it.kind == Kind.INFO }
    val failed get() = steps.filter { it.kind == Kind.FAIL }
}

/** Applies only what the device and Android really allow, and reports every outcome honestly. */
class OptimizationEngine(private val a: Activity, private val p: Prefs) {

    fun setAwake(on: Boolean) {
        if (on) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        p.setB("awake", on)
    }

    suspend fun run(profile: OptimizationProfile, game: GameInfo, onStep: (Step) -> Unit): OptimizationResult {
        val steps = mutableListOf<Step>()
        suspend fun add(k: Kind, t: String) {
            val s = Step(k, t); steps += s; onStep(s); delay(260)
        }
        GsLog.d("Optimizer", "profile=${profile.name} game=${game.pkg}")

        add(Kind.OK, "Device detected: ${Build.MANUFACTURER} ${Build.MODEL}")
        val sz = ShizukuBridge.state(a)
        val connected = sz == ShizukuState.CONNECTED
        if (connected) add(Kind.OK, "Shizuku connected")
        else add(Kind.INFO, "Shizuku not connected: running in limited mode. Connect Shizuku to use advanced optimization.")

        // Refresh rate: Android only lets an app request a mode for its own window.
        val rs = DisplayCtl.rates(a)
        if (profile.refresh == RefreshTarget.DEFAULT) {
            DisplayCtl.reset(a); p.setI("mode", 0)
            add(Kind.OK, "Refresh-rate preference reset to system default")
        } else if (rs.size < 2) {
            add(Kind.INFO, "Refresh rate: display reports only ${DisplayCtl.hz(a)} Hz")
        } else {
            val r = when (profile.refresh) { RefreshTarget.MIN -> rs.first(); RefreshTarget.MAX -> rs.last(); else -> rs[rs.size / 2] }
            DisplayCtl.apply(a, r.modeId); p.setI("mode", r.modeId)
            add(Kind.OK, "Refresh rate requested: ${r.hz} Hz (Game Space window; the game manages its own)")
        }

        // Resolution: system-wide, Shizuku only.
        if (!connected) {
            add(Kind.INFO, if (profile.scale < 1f) "Resolution skipped: requires Shizuku" else "Resolution unchanged")
        } else if (profile.scale >= 1f) {
            if (p.getB("res_modified", false)) {
                val r = ResolutionManager.reset(p)
                if (r.code == 0) add(Kind.OK, "Resolution restored to native") else add(Kind.FAIL, "Resolution restore failed: ${r.out}")
            } else add(Kind.INFO, "Resolution already native")
        } else {
            val base = ResolutionManager.physical()
            if (base == null) add(Kind.FAIL, "Resolution failed: could not read the screen size")
            else {
                val t = ResolutionManager.target(base, profile.scale)
                val r = ResolutionManager.apply(p, t)
                if (r.code == 0) add(Kind.OK, "Resolution: ${t.w} × ${t.h} (${String.format(Locale.US, "%.1f", profile.scale)}x)")
                else add(Kind.FAIL, "Resolution failed: ${r.out.ifBlank { "Shizuku command was rejected" }}")
            }
        }

        setAwake(profile.awake)
        add(Kind.OK, "Keep screen awake ${if (profile.awake) "on" else "off"} (Game Space)")
        // Android Game Mode, touch preset and DND (each reports its own real outcome)
        if (connected) {
            val gm = GameModeManager.set(profile.gameMode, game.pkg)
            if (gm.code == 0) add(Kind.OK, "Android Game Mode: ${profile.gameMode} (effect depends on the game and OEM)")
            else add(Kind.FAIL, "Game Mode failed: ${gm.out.ifBlank { "rejected" }}")
            val t = TouchPresets.apply(p, profile.touch)
            add(t.kind, t.text)
        } else add(Kind.INFO, "Game Mode and touch preset skipped: require Shizuku")
        if (profile.dnd != null) { val d = DndManager.apply(a, p, profile.dnd.filter); add(d.kind, d.text) }
        p.setS("profile", profile.name)
        add(Kind.OK, "Mode loaded: ${profile.title}")
        add(Kind.INFO, "Game FPS cannot be set by Android apps; MLBB controls its own FPS limit")
        val installed = try { a.packageManager.getLaunchIntentForPackage(game.pkg) != null } catch (e: Exception) { false }
        if (installed) add(Kind.OK, "Game ready: ${game.label}") else add(Kind.FAIL, "Game cannot be launched: ${game.label}")
        return OptimizationResult(steps)
    }

    /** Puts back everything this app changed during a session. */
    suspend fun restore(game: GameInfo?, onStep: (Step) -> Unit): List<Step> {
        val out = mutableListOf<Step>()
        fun add(st: Step) { out += st; onStep(st) }
        DisplayCtl.reset(a); p.setI("mode", 0); setAwake(false)
        add(Step(Kind.OK, "Refresh preference and keep-awake restored"))
        DndManager.restore(a, p)?.let { add(it) }
        if (ShizukuBridge.state(a) == ShizukuState.CONNECTED) {
            if (p.getB("lp_saved", false)) add(TouchPresets.apply(p, TouchPreset.DEFAULT))
            if (game != null) {
                val r = GameModeManager.set("standard", game.pkg)
                add(Step(if (r.code == 0) Kind.OK else Kind.FAIL, if (r.code == 0) "Game Mode back to standard" else "Game Mode restore failed: ${r.out}"))
            }
            if (p.getB("fx_gray", false)) add(com.sanju.systemx.system.ColorFx.setGray(p, false))
            if (p.getB("res_modified", false)) {
                val r = ResolutionManager.reset(p)
                add(Step(if (r.code == 0) Kind.OK else Kind.FAIL, if (r.code == 0) "Resolution restored to native" else "Resolution restore failed: ${r.out}"))
            }
        } else add(Step(Kind.INFO, "Shizuku not connected: touch, Game Mode, grayscale and resolution were not touched"))
        return out
    }
}
