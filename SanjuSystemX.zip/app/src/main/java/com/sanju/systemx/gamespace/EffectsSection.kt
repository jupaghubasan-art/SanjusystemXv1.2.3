package com.sanju.systemx.gamespace

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.overlay.OverlayService
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.system.ColorFx
import com.sanju.systemx.system.ColorPreset
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.chips
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import kotlinx.coroutines.launch

/** A labelled slider; progress is offset by [min] so negative ranges work. */
fun GameSpaceActivity.slider(title: String, min: Int, max: Int, value: Int, enabled: Boolean = true, onChange: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val l = label("$title: $value", 12f, if (enabled) Pal.text else Pal.sub)
    box.addView(l)
    box.addView(SeekBar(this).apply {
        this.max = max - min; progress = value - min; isEnabled = enabled
        progressTintList = ColorStateList.valueOf(Pal.RED); thumbTintList = ColorStateList.valueOf(Pal.BLUE)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { l.text = "$title: ${p + min}"; if (fromUser) onChange(p + min) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    })
    return box
}

/** EFFECTS: real tint/dim overlay over the game, Shizuku grayscale. Saturation/contrast are shown as unsupported. */
fun GameSpaceActivity.effectsSection(): View {
    val act = this
    val canOverlay = Settings.canDrawOverlays(this)
    val connected = vm.shizuku.value == ShizukuState.CONNECTED
    var temp = prefs.getI("fx_temp", 0)
    var dim = prefs.getI("fx_dim", 0)
    var inten = prefs.getI("fx_int", 60)
    var gray = prefs.getB("fx_gray", false)
    val out = label(if (prefs.getB("fx_on", false)) "Filter is ON" else "Filter is off", 12f, Pal.sub)

    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    root.weight(left, 1f); root.weight(right, 1f, dp(12))

    val tempS = slider("Temperature (− cool … + warm)", -100, 100, temp) { temp = it }
    val dimS = slider("Brightness dim %", 0, 45, dim) { dim = it }
    val intS = slider("Filter intensity %", 0, 100, inten) { inten = it }
    left.put(box("GAME COLOUR").apply {
        put(chips(ColorPreset.values().map { it.title }, null, false) { t ->
            val p = ColorPreset.values().first { it.title == t }
            if (!p.supported) { out.text = "ℹ ${p.title} is not possible: Android does not let a normal app change another app's saturation/contrast."; return@chips }
            temp = p.temp; dim = p.dim; gray = p.gray
            ((tempS.getChildAt(1)) as SeekBar).progress = temp + 100
            ((dimS.getChildAt(1)) as SeekBar).progress = dim
            out.text = "Preset ${p.title} loaded. Tap APPLY."
        }, 6)
        put(tempS, 8); put(dimS, 4); put(intS, 4)
        put(slider("Saturation (unsupported)", 0, 100, 50, false) { }, 4)
        put(slider("Contrast (unsupported)", 0, 100, 50, false) { }, 4)
        put(btn("APPLY") {
            prefs.setI("fx_temp", temp); prefs.setI("fx_dim", dim); prefs.setI("fx_int", inten)
            if (gray && !connected) { out.text = "✕ Grayscale needs Shizuku."; return@btn }
            if (temp != 0 || dim != 0) {
                if (!Settings.canDrawOverlays(act)) { out.text = "✕ Grant 'display over other apps' first (right side)."; return@btn }
                prefs.setB("fx_on", true)
                if (OverlayService.running()) OverlayService.refreshFilter() else OverlayService.start(act)
            } else { prefs.setB("fx_on", false); OverlayService.refreshFilter() }
            act.lifecycleScope.launch {
                val s = if (connected) ColorFx.setGray(prefs, gray) else null
                out.text = "✓ Applied tint/dim overlay." + (s?.let { "\n" + (if (it.kind == com.sanju.systemx.optimizer.Kind.OK) "✓ " else "✕ ") + it.text } ?: "")
            }
        }, 10)
        put(btn("RESET TO DEFAULT", false) {
            prefs.setI("fx_temp", 0); prefs.setI("fx_dim", 0); prefs.setI("fx_int", 60); prefs.setB("fx_on", false)
            OverlayService.refreshFilter()
            act.lifecycleScope.launch { if (connected && prefs.getB("fx_gray", false)) ColorFx.setGray(prefs, false) }
            out.text = "✓ Colour effects reset. Your normal display settings are unchanged."
            renderSection()
        }, 8)
        put(out, 8)
    }, 0)

    right.put(box("PERMISSION").apply {
        put(label(if (canOverlay) "Overlay permission: GRANTED" else "Overlay permission: NOT GRANTED", 12f, if (canOverlay) Pal.GREEN else AMBER, true), 4)
        if (!canOverlay) put(btn("GRANT OVERLAY PERMISSION", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, 6)
    }, 0)
    right.put(box("WHAT THIS CAN DO").apply {
        put(label("✓ Tint (warm/cool) and dim the whole screen, including the game, with a touch-through overlay. It never blocks game controls.", 11f, Pal.text), 4)
        put(label("✓ Grayscale through Android's own colour correction (needs Shizuku).", 11f, Pal.text), 4)
        put(label("✕ Saturation, contrast and 'Vivid' cannot be applied to another app by a normal app. No game files are touched and nothing is injected.", 11f, AMBER), 4)
        put(label("Colour effects run inside the floating-panel service, so the panel bubble also appears while a filter is on.", 10f, Pal.sub), 4)
    })
    return root
}
