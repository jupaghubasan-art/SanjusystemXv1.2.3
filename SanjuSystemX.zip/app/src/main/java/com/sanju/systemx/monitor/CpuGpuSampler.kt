package com.sanju.systemx.monitor

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.sanju.systemx.shizuku.ShizukuBridge

/** CPU load from /proc/stat (readable only with shell access, so Shizuku) and MediaTek GED GPU utilization when present. */
class CpuGpuSampler {
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var primed = false

    suspend fun cpuPercent(): Float? {
        val r = ShizukuBridge.exec("cat", "/proc/stat")
        if (r.code != 0) return null
        val line = r.out.lineSequence().firstOrNull { it.startsWith("cpu ") } ?: return null
        val v = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (v.size < 5) return null
        val idle = v[3] + v[4]
        val total = v.sum()
        val dT = total - lastTotal; val dI = idle - lastIdle
        val first = !primed
        lastTotal = total; lastIdle = idle; primed = true
        return if (first || dT <= 0) null else ((dT - dI) * 100f / dT).coerceIn(0f, 100f)
    }

    suspend fun gpuPercent(): Float? {
        val r = ShizukuBridge.exec("cat", "/sys/kernel/ged/hal/gpu_utilization")
        if (r.code != 0) return null
        val n = Regex("\\d+").find(r.out)?.value?.toFloatOrNull() ?: return null
        return if (n in 0f..100f) n else null
    }
}

object ThermalInfo {
    /** Android's public thermal status (API 29+). */
    fun status(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 29) return "Unavailable"
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
            PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
            PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
            PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
            PowerManager.THERMAL_STATUS_CRITICAL, PowerManager.THERMAL_STATUS_EMERGENCY, PowerManager.THERMAL_STATUS_SHUTDOWN -> "CRITICAL"
            else -> "UNKNOWN"
        }
    }
}
