package com.sanju.systemx.settings

/** Small in-memory debug log (last 100 lines). Never stores personal data. */
object GsLog {
    private val buf = ArrayDeque<String>()

    fun d(tag: String, msg: String) {
        synchronized(buf) {
            if (buf.size >= 100) buf.removeFirst()
            buf.addLast("[$tag] $msg")
        }
        android.util.Log.d("SanjuX", "[$tag] $msg")
    }

    fun dump(): String = synchronized(buf) { buf.joinToString("\n") }.ifEmpty { "(empty)" }
}
