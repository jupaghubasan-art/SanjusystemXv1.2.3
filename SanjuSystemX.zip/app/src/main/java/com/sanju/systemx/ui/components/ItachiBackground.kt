package com.sanju.systemx.ui.components

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import com.sanju.systemx.ui.animations.ItachiArt
import kotlin.math.sin

/**
 * Optional Itachi-inspired ambient background: red moon, slow ravens, feathers, smoke, faint Sharingan glow.
 * mode 0 = static (drawn once), 1 = low (~10 fps, fewer elements), 2 = full (~24 fps).
 * Animation runs only while [running] is true (the activity pauses it when not visible).
 */
class ItachiBackground(ctx: Context) : View(ctx) {
    var mode = 1
        set(v) { field = v; schedule() }
    var running = false
        set(v) { field = v; schedule() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var sky: LinearGradient? = null
    private var moon: RadialGradient? = null
    private var smoke: RadialGradient? = null
    private var glow: RadialGradient? = null
    private val start = System.nanoTime()
    private val d get() = resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sky = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF0B0F1A.toInt(), 0xFF070A12.toInt(), Shader.TileMode.CLAMP)
        moon = RadialGradient(0f, 0f, h * 0.26f, intArrayOf(0x66B3131F, 0x33B3131F, 0x00B3131F), floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
        smoke = RadialGradient(0f, 0f, h * 0.45f, 0x22401018, 0x00401018, Shader.TileMode.CLAMP)
        glow = RadialGradient(0f, 0f, h * 0.35f, 0x33D7263D, 0x00D7263D, Shader.TileMode.CLAMP)
    }

    private fun interval() = if (mode >= 2) 42L else 100L

    private val tick = Runnable { invalidate() }

    private fun schedule() {
        removeCallbacks(tick)
        if (running && mode > 0 && isAttachedToWindow) postDelayed(tick, interval()) else invalidate()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); schedule() }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = if (running && mode > 0) (System.nanoTime() - start) / 1e9f else 0f
        p.style = Paint.Style.FILL; p.shader = sky; p.alpha = 255; c.drawRect(0f, 0f, w, h, p)
        // moon
        c.save(); c.translate(w * 0.78f + 8 * d * sin(t * 0.15f), h * 0.30f + 4 * d * sin(t * 0.2f))
        p.shader = moon; c.drawCircle(0f, 0f, h * 0.26f, p); c.restore()
        if (mode >= 2) {
            for (i in 0 until 3) {
                c.save(); c.translate(w * (0.2f + 0.3f * i) + 30 * d * sin(t * 0.1f + i), h * (0.75f + 0.1f * sin(t * 0.13f + i)))
                p.shader = smoke; c.drawCircle(0f, 0f, h * 0.45f, p); c.restore()
            }
            c.save(); c.translate(w * 0.08f, h * 0.9f); p.alpha = (140 + 100 * sin(t * 0.8f)).toInt().coerceIn(0, 255)
            p.shader = glow; c.drawCircle(0f, 0f, h * 0.35f, p); c.restore()
        }
        p.shader = null
        // ravens (slow, faint)
        p.color = 0xFF04060B.toInt(); p.alpha = 150
        val crows = if (mode >= 2) 4 else if (mode == 1) 2 else 0
        for (i in 0 until crows) {
            val prog = ((t * 0.02f + i * 0.27f) % 1f)
            ItachiArt.crow(path, w * (1.1f - 1.3f * prog), h * (0.18f + 0.14f * i + 0.02f * sin(t + i)), h * 0.05f, sin(t * 3f + i) * 0.7f + 0.3f)
            c.drawPath(path, p)
        }
        // feathers
        p.color = 0xFF121826.toInt(); p.alpha = 200
        val feathers = if (mode >= 2) 10 else if (mode == 1) 5 else 0
        for (i in 0 until feathers) {
            val prog = (t * 0.03f + i * 0.11f) % 1f
            val x = w * ((i * 0.37f) % 1f) + 14 * d * sin(prog * 8f + i); val y = h * prog
            c.save(); c.rotate(prog * 200f + i * 40f, x, y)
            c.drawOval(x - 4 * d, y - 1.4f * d, x + 4 * d, y + 1.4f * d, p); c.restore()
        }
        if (running && mode > 0) { removeCallbacks(tick); postDelayed(tick, interval()) }
    }
}
