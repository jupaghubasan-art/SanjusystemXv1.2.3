package com.sanju.systemx.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.sanju.systemx.monitor.CpuGpuSampler
import com.sanju.systemx.monitor.FpsSampler
import com.sanju.systemx.optimizer.Kind
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.system.ColorFx
import com.sanju.systemx.system.DndManager
import com.sanju.systemx.system.DndMode
import com.sanju.systemx.system.TouchPreset
import com.sanju.systemx.system.TouchPresets
import com.sanju.systemx.ui.LineChartView
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.animations.ItachiArt
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.StatRow
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/** Touch-through full-screen tint/dim layer for the game colour effect. */
class FilterView(ctx: Context) : View(ctx) {
    private var tint = 0
    private var dim = 0
    fun set(t: Int, d: Int) { tint = t; dim = d; invalidate() }
    override fun onDraw(c: Canvas) { if (tint != 0) c.drawColor(tint); if (dim != 0) c.drawColor(dim) }
}

/** Floating game panel: bubble ⇄ expandable panel, draggable, live FPS/Hz/temp/CPU, quick actions. */
class OverlayService : Service() {
    companion object {
        @Volatile var instance: OverlayService? = null
        const val ACTION_STOP = "com.sanju.systemx.STOP_PANEL"
        private const val CH = "panel"
        fun start(ctx: Context) { ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, OverlayService::class.java)) }
        fun running() = instance != null
        fun refreshFilter() { instance?.applyFilter() }
        fun refreshOpacity() { instance?.applyOpacity() }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var ui: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val fps = FpsSampler()
    private val cpu = CpuGpuSampler()
    private var host: FrameLayout? = null
    private var hostParams: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var bubble: View? = null
    private var filter: FilterView? = null
    private var pollJob: Job? = null
    private lateinit var sFps: StatRow
    private lateinit var sHz: StatRow
    private lateinit var sTemp: StatRow
    private lateinit var sCpu: StatRow
    private lateinit var source: TextView
    private lateinit var status: TextView
    private lateinit var chart: LineChartView
    private var pingMs: String = ""
    private var headView: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        Pal.dark = prefs.getB("dark", true)
        ui = android.view.ContextThemeWrapper(this, R.style.Theme_SanjuSystemX)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        if (!Settings.canDrawOverlays(this)) { GsLog.d("Overlay", "permission missing"); stopSelf(); return }
        buildHost()
        applyFilter()
        GsLog.d("Overlay", "started")
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        instance = null
        pollJob?.cancel()
        if (fps.hasData) prefs.setS("last_fps", fps.summary())
        host?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        filter?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        scope.cancel()
        GsLog.d("Overlay", "stopped")
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Floating panel", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("ITACHI GAME SPACE panel active")
            .setContentText("Tap STOP to remove the floating panel")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ───────── colour filter ─────────
    fun applyFilter() {
        if (!prefs.getB("fx_on", false)) {
            filter?.let { try { wm.removeView(it) } catch (e: Exception) { } }
            filter = null
            return
        }
        val v = filter ?: FilterView(this).also {
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(it, lp); filter = it
        }
        val inten = prefs.getI("fx_int", 60)
        v.set(ColorFx.tintColor(prefs.getI("fx_temp", 0), inten), ColorFx.dimColor(prefs.getI("fx_dim", 0)))
    }

    fun applyOpacity() { panel?.alpha = prefs.getI("panel_alpha", 85) / 100f }

    // ───────── floating panel ─────────
    private fun buildHost() {
        val c = ui
        val h = FrameLayout(c)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                (if (prefs.getB("awake", false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0),
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = c.dp(8); y = c.dp(40) }
        hostParams = p
        val b = object : View(c) {
            override fun onDraw(cv: Canvas) {
                val r = width / 2f
                val pa = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6121827.toInt() }
                cv.drawCircle(r, r, r, pa); ItachiArt.mangekyo(cv, r, r, r * 0.8f, 0f, pa)
            }
        }.apply { contentDescription = "Open game panel" }
        bubble = b
        panel = buildPanel()
        panel!!.visibility = View.GONE
        h.addView(b, FrameLayout.LayoutParams(c.dp(44), c.dp(44)))
        h.addView(panel, FrameLayout.LayoutParams(c.dp(310), FrameLayout.LayoutParams.WRAP_CONTENT))
        drag(b, p, h) { expand(true) }
        headView?.let { drag(it, p, h) { } }
        host = h
        wm.addView(h, p)
        applyOpacity()
    }

    private fun drag(handle: View, p: WindowManager.LayoutParams, target: View, onTap: () -> Unit) {
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = p.x; iy = p.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { p.x = ix + dx.toInt(); p.y = iy + dy.toInt(); try { wm.updateViewLayout(target, p) } catch (x: Exception) { } }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap(); true }
                else -> false
            }
        }
    }

    private fun expand(on: Boolean) {
        panel?.visibility = if (on) View.VISIBLE else View.GONE
        bubble?.visibility = if (on) View.GONE else View.VISIBLE
        pollJob?.cancel()
        if (on) {
            fps.reset()
            pollJob = scope.launch { while (isActive) { tick(); delay(2000) } }
        } else if (fps.hasData) prefs.setS("last_fps", fps.summary())
        host?.let { try { wm.updateViewLayout(it, hostParams) } catch (e: Exception) { } }
    }

    private fun buildPanel(): View {
        val c = ui
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(10))
            background = GradientDrawable().apply { setColor(0xF0121827.toInt()); cornerRadius = c.dp(14).toFloat(); setStroke(c.dp(1), 0x66D7263D) }
        }
        val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(c.label("ITACHI GAME PANEL", 11f, Pal.text, true).apply { letterSpacing = 0.1f }, lp(0, -2, 1f))
        head.addView(c.label("–", 20f, Pal.text, true).apply { setPadding(c.dp(10), 0, c.dp(10), 0); contentDescription = "Minimize"; setOnClickListener { expand(false) } })
        head.addView(c.label("✕", 15f, Pal.text, true).apply { setPadding(c.dp(10), 0, 0, 0); contentDescription = "Close panel"; setOnClickListener { closePanel() } })
        root.addView(head)
        headView = head
        sFps = StatRow(c, "FPS", "—"); sHz = StatRow(c, "HZ", "—"); sTemp = StatRow(c, "TEMP", "—"); sCpu = StatRow(c, "CPU", "—")
        val stats = LinearLayout(c)
        listOf(sFps, sHz, sTemp, sCpu).forEach { stats.addView(it.view, lp(0, -2, 1f).apply { marginEnd = c.dp(6) }) }
        root.addView(stats, lp(-1, -2).apply { topMargin = c.dp(6) })
        source = c.label("FPS source: —", 9f, Pal.sub)
        root.addView(source)
        chart = LineChartView(c, "FPS history", null, 56)
        root.addView(chart, lp(-1, -2))
        val tiles = LinearLayout(c)
        fun tile(t: String, f: () -> Unit) = c.btn(t, false) { f() }.apply { textSize = 10f; minimumHeight = c.dp(34); minHeight = c.dp(34); setPadding(c.dp(4), 0, c.dp(4), 0) }
        tiles.addView(tile("TOUCH") { cycleTouch() }, lp(0, -2, 1f))
        tiles.addView(tile("DND") { toggleDnd() }, lp(0, -2, 1f))
        tiles.addView(tile("FILTER") { toggleFilter() }, lp(0, -2, 1f))
        tiles.addView(tile("PING") { ping() }, lp(0, -2, 1f))
        tiles.addView(tile("RESTORE") { restore() }, lp(0, -2, 1f))
        root.addView(tiles, lp(-1, -2).apply { topMargin = c.dp(6) })
        status = c.label("Ready", 10f, Pal.sub)
        root.addView(status)
        return root
    }

    private fun closePanel() {
        if (prefs.getB("restore_on_close", true)) restore { stopSelf() } else stopSelf()
    }

    private suspend fun tick() {
        val c = ui
        val connected = ShizukuBridge.state(this) == ShizukuState.CONNECTED
        val hz = Math.round((getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY).refreshRate)
        sHz.value.text = "$hz"
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        sTemp.value.text = if (t == Int.MIN_VALUE) "N/A" else "${Math.round(t / 10f)}°C"
        val pkg = prefs.getS("game", "")
        if (!connected || pkg.isEmpty()) {
            sFps.value.text = "N/A"; sCpu.value.text = "N/A"
            source.text = if (!connected) "FPS/CPU need Shizuku connected" else "Select a game in Game Space first"
            return
        }
        val r = fps.sample(pkg)
        sFps.value.text = r.fps?.let { "${Math.round(it)}" } ?: "N/A"
        source.text = "FPS source: ${r.source}"
        if (r.fps != null) { chart.push(r.fps) }
        sCpu.value.text = cpu.cpuPercent()?.let { "${Math.round(it)}%" } ?: "…"
        status.text = (if (fps.hasData) fps.summary() else "Waiting for frames…") + pingMs
    }

    private fun say(m: String) { status.text = m }

    private fun cycleTouch() {
        scope.launch {
            if (ShizukuBridge.state(this@OverlayService) != ShizukuState.CONNECTED) { say("Touch preset needs Shizuku"); return@launch }
            val next = TouchPreset.values()[(TouchPreset.values().indexOfFirst { it.name == prefs.getS("touch", "DEFAULT") } + 1) % 3]
            say(TouchPresets.apply(prefs, next).let { (if (it.kind == Kind.OK) "✓ " else "✕ ") + it.text })
        }
    }

    private fun toggleDnd() {
        if (!DndManager.hasAccess(this)) { say("DND needs notification-policy access (open the app > Panel)"); return }
        val s = if (prefs.getI("dnd_prev", -1) == -1) DndManager.apply(this, prefs, DndMode.GAMING.filter) else (DndManager.restore(this, prefs) ?: com.sanju.systemx.optimizer.Step(Kind.INFO, "No DND change to restore"))
        say((if (s.kind == Kind.OK) "✓ " else "ℹ ") + s.text)
    }

    private fun toggleFilter() {
        val on = !prefs.getB("fx_on", false)
        prefs.setB("fx_on", on)
        applyFilter()
        say("Game colour ${if (on) "on" else "off"} (tint/dim overlay)")
    }

    private fun ping() {
        scope.launch {
            if (ShizukuBridge.state(this@OverlayService) != ShizukuState.CONNECTED) { say("Ping needs Shizuku"); return@launch }
            val host = prefs.getS("ping_host", "1.1.1.1")
            say("Pinging $host…")
            val r = ShizukuBridge.exec("ping", "-c", "1", "-W", "2", host)
            val ms = Regex("time=([0-9.]+)").find(r.out)?.groupValues?.get(1)?.toFloatOrNull()
            pingMs = if (ms != null) String.format(Locale.US, " · ping %.0f ms", ms) else ""
            say(if (ms != null) String.format(Locale.US, "✓ Ping to %s: %.0f ms (one-time test)", host, ms) else "✕ Ping failed or timed out")
        }
    }

    private fun restore(done: (() -> Unit)? = null) {
        scope.launch {
            prefs.setB("fx_on", false); applyFilter()
            DndManager.restore(this@OverlayService, prefs)
            if (ShizukuBridge.state(this@OverlayService) == ShizukuState.CONNECTED) {
                if (prefs.getB("lp_saved", false)) TouchPresets.apply(prefs, TouchPreset.DEFAULT)
                if (prefs.getB("fx_gray", false)) ColorFx.setGray(prefs, false)
                val pkg = prefs.getS("game", "")
                if (pkg.isNotEmpty()) com.sanju.systemx.system.GameModeManager.set("standard", pkg)
                if (prefs.getB("res_modified", false)) ResolutionManager.reset(prefs)
            }
            say("✓ Restored: colour, DND, touch, Game Mode, resolution")
            done?.invoke()
        }
    }
}
