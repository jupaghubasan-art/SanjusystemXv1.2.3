package com.sanju.systemx.gamespace

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.R
import com.sanju.systemx.device.DeviceInfoProvider
import com.sanju.systemx.monitor.CpuGpuSampler
import com.sanju.systemx.monitor.ThermalInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.ui.LineChartView
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/** MONITOR: real measurements only, each with its source. UI FPS is this app's own rendering, never game FPS. */
fun GameSpaceActivity.monitorSection(): View {
    val act = this
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    root.weight(left, 1f)
    root.weight(right, 1f, dp(12))

    val fpsChart = LineChartView(this, "UI FPS · this app only (not game FPS)", null)
    val ramChart = LineChartView(this, "SYSTEM RAM USED %", 100f)
    val metrics = label("Press START to measure.", 13f)
    val pingOut = label("", 11f, Pal.sub)
    val probe = View(this).apply { setBackgroundColor(Pal.RED) }
    var started = false
    var cpuTxt = "measuring…"
    var gpuTxt = "measuring…"
    val cg = CpuGpuSampler()

    fun begin() {
        if (started) return
        started = true
        monitor.start()
        probeAnim = ObjectAnimator.ofFloat(probe, "rotation", 0f, 360f).apply {
            duration = 1200; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); start()
        }
        extraJob = act.lifecycleScope.launch {
            while (isActive) {
                if (vm.shizuku.value == ShizukuState.CONNECTED) {
                    cpuTxt = cg.cpuPercent()?.let { "${Math.round(it)}% (Shizuku /proc/stat)" } ?: "measuring…"
                    gpuTxt = cg.gpuPercent()?.let { "${Math.round(it)}% (MediaTek GED via Shizuku)" } ?: "Unavailable (device does not expose it)"
                } else {
                    cpuTxt = "Unavailable (needs Shizuku)"; gpuTxt = "Unavailable (needs Shizuku)"
                }
                delay(2000)
            }
        }
        val g = vm.graphics.value
        liveUpdater = { s ->
            fpsChart.push(s.fps); ramChart.push(s.ramPct)
            metrics.text = "UI FPS (render probe): ${Math.round(s.fps)}\n" +
                "CPU USAGE: $cpuTxt\nCPU FREQ: ${s.cpu}\n" +
                "GPU: ${g?.renderer ?: "Unavailable"}\nGPU UTILIZATION: $gpuTxt\n" +
                "GRAPHICS API: ${g?.apiSummary ?: "Unavailable"}\n" +
                "SYSTEM RAM: ${s.ramText}\nAPP MEMORY: ${s.heapMb} MB\n" +
                "BATTERY: ${if (s.battery >= 0) "${s.battery}%" else "n/a"}${if (s.charging) " (charging)" else ""}\n" +
                "BATTERY TEMPERATURE: ${s.tempC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "Unavailable"}\n" +
                "THERMAL STATUS: ${ThermalInfo.status(act)}\n" +
                "DISPLAY REFRESH: ${DisplayCtl.hz(act)} Hz\n" +
                "LAST GAME FPS: ${prefs.getS("last_fps", "none (use the floating panel)")}"
        }
    }

    left.put(box("LIVE MONITOR").apply {
        put(fpsChart, 6)
        put(ramChart, 6)
        put(LinearLayout(act).apply {
            addView(label("Render probe (needed to measure UI FPS): ", 11f, Pal.sub))
            addView(probe, lp(dp(12), dp(12)))
        }, 6)
        if (!prefs.getB("autoMon", true)) put(btn("START MONITOR") { v -> v.isEnabled = false; begin() }, 8)
    }, 0)
    left.put(box("NETWORK PING (ONE-TIME)").apply {
        put(btn("PING ${prefs.getS("ping_host", "1.1.1.1")}", false) {
            act.lifecycleScope.launch {
                if (vm.shizuku.value != ShizukuState.CONNECTED) { pingOut.text = "✕ Needs Shizuku"; return@launch }
                val h = prefs.getS("ping_host", "1.1.1.1")
                pingOut.text = "Pinging $h…"
                val r = ShizukuBridge.exec("ping", "-c", "1", "-W", "2", h)
                val ms = Regex("time=([0-9.]+)").find(r.out)?.groupValues?.get(1)?.toFloatOrNull()
                pingOut.text = if (ms != null) String.format(Locale.US, "✓ %.0f ms to %s", ms, h) else "✕ No reply"
            }
        }, 4)
        put(pingOut, 4)
    })
    right.put(box("METRICS").apply { put(metrics, 6) }, 0)
    if (prefs.getB("showStats", true)) {
        right.put(box("DEVICE INFORMATION").apply {
            DeviceInfoProvider.rows(act, vm.graphics.value).forEach { (k, v) -> put(label("$k  ·  $v", 12f, Pal.text), 3) }
        })
    }
    if (prefs.getB("autoMon", true)) begin()
    return root
}
