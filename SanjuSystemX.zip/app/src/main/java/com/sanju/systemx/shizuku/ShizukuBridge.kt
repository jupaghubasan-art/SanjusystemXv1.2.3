package com.sanju.systemx.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_INSTALLED, NOT_RUNNING, NEEDS_PERMISSION, CONNECTED }

/**
 * Optional privileged access through Shizuku (no root). Only the fixed command shapes listed in [allowed]
 * can ever run; arguments are validated and passed as an argument array (never through a shell string).
 */
object ShizukuBridge {
    private const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242
    private val sizeArg = Regex("^\\d{3,5}x\\d{3,5}$")
    private val pkgRx = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$")
    private val layerRx = Regex("^[A-Za-z0-9_.\\[\\]()#/\$:\\- ]{3,220}$")
    private val ipRx = Regex("^(\\d{1,3})(\\.\\d{1,3}){3}$")
    private val readKeys = setOf("long_press_timeout", "accessibility_display_daltonizer_enabled", "accessibility_display_daltonizer")

    data class Result(val code: Int, val out: String)

    @Suppress("DEPRECATION")
    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0); true
    } catch (e: Exception) { false }

    fun state(ctx: Context): ShizukuState {
        if (!isInstalled(ctx)) return ShizukuState.NOT_INSTALLED
        val running = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!running) return ShizukuState.NOT_RUNNING
        val ok = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
        return if (ok) ShizukuState.CONNECTED else ShizukuState.NEEDS_PERMISSION
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (e: Throwable) { /* not running */ }
    }

    fun statusText(ctx: Context): String = when (state(ctx)) {
        ShizukuState.NOT_INSTALLED -> "Shizuku is not installed.\nAdvanced system operations unavailable.\nShizuku Status: Not Connected"
        ShizukuState.NOT_RUNNING -> "Shizuku is installed but not running. Open the Shizuku app and start it (Wireless debugging), then tap the button below.\nShizuku Status: Not Connected"
        ShizukuState.NEEDS_PERMISSION -> "Shizuku is running. Tap the button below and allow the app.\nShizuku Status: Not Connected"
        ShizukuState.CONNECTED -> "Shizuku Status: Connected ✔\nOnly a fixed list of commands is used, and risky ones ask your confirmation first."
    }

    private fun settingOk(key: String, v: String): Boolean = when (key) {
        "long_press_timeout" -> v.toIntOrNull()?.let { it in 100..3000 } == true
        "accessibility_display_daltonizer_enabled" -> v == "0" || v == "1"
        "accessibility_display_daltonizer" -> v == "0"
        else -> false
    }

    private fun allowed(c: Array<out String>): Boolean {
        val j = c.joinToString(" ")
        return when {
            j == "wm size" || j == "wm size reset" -> true
            c.size == 3 && c[0] == "wm" && c[1] == "size" -> sizeArg.matches(c[2])
            j == "dumpsys SurfaceFlinger --list" -> true
            c.size == 4 && c[0] == "dumpsys" && c[1] == "SurfaceFlinger" && c[2] == "--latency" -> layerRx.matches(c[3])
            j == "cat /proc/stat" || j == "cat /sys/kernel/ged/hal/gpu_utilization" -> true
            c.size == 5 && c[0] == "cmd" && c[1] == "game" && c[2] == "mode" ->
                c[3] in setOf("standard", "performance", "battery") && pkgRx.matches(c[4])
            c.size == 5 && c[0] == "settings" && c[1] == "put" && c[2] == "secure" -> settingOk(c[3], c[4])
            c.size == 4 && c[0] == "settings" && c[1] == "get" && c[2] == "secure" -> c[3] in readKeys
            c.size == 6 && c[0] == "ping" && c[1] == "-c" && c[2] == "1" && c[3] == "-W" && c[4] == "2" ->
                ipRx.matches(c[5]) && c[5].split(".").all { it.toInt() in 0..255 }
            else -> false
        }
    }

    suspend fun exec(vararg cmd: String): Result = withContext(Dispatchers.IO) {
        if (!allowed(cmd)) return@withContext Result(-1, "Command not allowed")
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf(*cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            Result(p.waitFor(), (out + err).trim())
        } catch (e: Throwable) {
            Result(-1, e.message ?: e.javaClass.simpleName)
        }
    }
}
