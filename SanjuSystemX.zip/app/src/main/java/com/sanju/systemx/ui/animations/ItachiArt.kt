package com.sanju.systemx.ui.animations

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.cos
import kotlin.math.sin

/** Original vector drawing helpers (ravens, Sharingan-style emblem, hooded silhouette). No third-party artwork is used. */
object ItachiArt {
    /** Raven silhouette. flap in -0.6..1 moves the wing tips. */
    fun crow(path: Path, cx: Float, cy: Float, s: Float, flap: Float) {
        path.reset()
        path.moveTo(cx - s * 0.30f, cy); path.quadTo(cx, cy - s * 0.10f, cx + s * 0.34f, cy - s * 0.04f)
        path.lineTo(cx + s * 0.48f, cy - s * 0.02f); path.lineTo(cx + s * 0.34f, cy + s * 0.04f)
        path.quadTo(cx, cy + s * 0.12f, cx - s * 0.30f, cy); path.close()
        for (side in intArrayOf(-1, 1)) {
            path.moveTo(cx + side * s * 0.05f, cy - s * 0.02f)
            path.quadTo(cx + side * s * 0.40f, cy - s * 0.55f * flap, cx + side * s * 0.95f, cy - s * 0.22f * flap + s * 0.10f)
            path.quadTo(cx + side * s * 0.45f, cy - s * 0.10f * flap, cx + side * s * 0.02f, cy + s * 0.06f)
            path.close()
        }
    }

    /** Sharingan-style emblem: red disc, dark ring, pupil and three tomoe. */
    fun sharingan(c: Canvas, cx: Float, cy: Float, r: Float, angle: Float, p: Paint) {
        p.style = Paint.Style.FILL
        p.color = 0xFFB3131F.toInt(); c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.08f; p.color = 0xFF160508.toInt()
        c.drawCircle(cx, cy, r * 0.62f, p)
        p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r * 0.17f, p)
        for (k in 0 until 3) {
            val a = angle + k * 2.0944f
            c.drawCircle(cx + cos(a) * r * 0.62f, cy + sin(a) * r * 0.62f, r * 0.13f, p)
        }
    }

    /** Stylized hooded figure with a high collar, headband and two glowing red eyes. */
    fun silhouette(c: Canvas, cx: Float, baseY: Float, h: Float, a: Float, glow: Float, p: Paint) {
        val al = (255 * a).toInt().coerceIn(0, 255)
        p.style = Paint.Style.FILL
        p.color = 0xFF05060A.toInt(); p.alpha = al
        val collar = Path().apply {
            moveTo(cx - h * 0.62f, baseY); lineTo(cx - h * 0.40f, baseY - h * 0.50f)
            lineTo(cx - h * 0.16f, baseY - h * 0.40f); lineTo(cx + h * 0.16f, baseY - h * 0.40f)
            lineTo(cx + h * 0.46f, baseY - h * 0.55f); lineTo(cx + h * 0.66f, baseY); close()
        }
        c.drawPath(collar, p)
        c.drawOval(cx - h * 0.17f, baseY - h * 0.92f, cx + h * 0.17f, baseY - h * 0.40f, p)
        val hair = Path().apply {
            moveTo(cx - h * 0.22f, baseY - h * 0.80f); lineTo(cx - h * 0.34f, baseY - h * 0.38f)
            lineTo(cx - h * 0.14f, baseY - h * 0.52f); lineTo(cx + h * 0.02f, baseY - h * 0.30f)
            lineTo(cx + h * 0.16f, baseY - h * 0.52f); lineTo(cx + h * 0.30f, baseY - h * 0.40f)
            lineTo(cx + h * 0.22f, baseY - h * 0.82f); close()
        }
        c.drawPath(hair, p)
        p.color = 0xFF20283A.toInt(); p.alpha = al
        c.drawRect(cx - h * 0.18f, baseY - h * 0.78f, cx + h * 0.18f, baseY - h * 0.72f, p)
        // eyes
        val ey = baseY - h * 0.64f
        for (sx in floatArrayOf(-0.07f, 0.07f)) {
            val ex = cx + h * sx
            p.color = 0xFFD7263D.toInt(); p.alpha = (110 * glow).toInt(); c.drawCircle(ex, ey, h * 0.07f, p)
            p.alpha = (255 * glow * a).toInt().coerceIn(0, 255); c.drawCircle(ex, ey, h * 0.022f, p)
        }
    }
}
