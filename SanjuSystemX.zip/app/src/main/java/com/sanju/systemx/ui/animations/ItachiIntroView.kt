package com.sanju.systemx.ui.animations

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.sin

/**
 * 4–5 s opening: dark sky and red moon, ravens crossing, falling feathers, a hooded silhouette with glowing red eyes,
 * logo, loading bar. Driven by one animator value t (0..1); redraws only while that animator runs.
 */
class ItachiIntroView(ctx: Context) : View(ctx) {
    var t = 0f
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rnd = java.util.Random(11)
    private val crowY = FloatArray(6) { 0.12f + rnd.nextFloat() * 0.5f }
    private val crowS = FloatArray(6) { 0.045f + rnd.nextFloat() * 0.05f }
    private val crowOff = FloatArray(6) { rnd.nextFloat() * 0.25f }
    private val fx = FloatArray(12) { rnd.nextFloat() }
    private val fy = FloatArray(12) { rnd.nextFloat() }
    private var sky: LinearGradient? = null
    private var moon: RadialGradient? = null
    private val d get() = resources.displayMetrics.density

    private fun seg(v: Float, a: Float, b: Float) = ((v - a) / (b - a)).coerceIn(0f, 1f)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sky = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF0B0F1A.toInt(), 0xFF05060A.toInt(), Shader.TileMode.CLAMP)
        val r = h * 0.28f
        moon = RadialGradient(0f, 0f, r, intArrayOf(0xFFC21B2C.toInt(), 0xFF8E1220.toInt(), 0x00600A14), floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2
        p.style = Paint.Style.FILL; p.shader = sky; p.alpha = 255; c.drawRect(0f, 0f, w, h, p); p.shader = null

        // red moon rises
        val ma = seg(t, 0.03f, 0.3f)
        if (ma > 0f) {
            c.save(); c.translate(w * 0.68f, h * (0.62f - 0.28f * ma)); p.shader = moon; p.alpha = (255 * ma).toInt()
            c.drawCircle(0f, 0f, h * 0.28f, p); c.restore(); p.shader = null
        }

        // silhouette + glowing eyes
        val sa = seg(t, 0.32f, 0.58f)
        val eg = seg(t, 0.5f, 0.68f)
        if (sa > 0f) ItachiArt.silhouette(c, cx, h * 0.92f, h * 0.62f, sa, eg, p)
        if (eg > 0f) ItachiArt.sharingan(c, cx + h * 0.30f, h * 0.30f, h * 0.045f * eg, t * 8f, p)

        // ravens crossing right → left
        val ca = seg(t, 0.12f, 0.8f)
        p.color = 0xFF020306.toInt(); p.style = Paint.Style.FILL; p.alpha = 255
        for (i in crowY.indices) {
            val prog = ((ca - crowOff[i]) / 0.75f).coerceIn(0f, 1f)
            if (prog <= 0f || prog >= 1f) continue
            val x = w * (1.1f - 1.3f * prog)
            val y = h * (crowY[i] + 0.04f * sin(prog * 6f + i))
            ItachiArt.crow(path, x, y, h * crowS[i] * 2f, sin(t * 60f + i * 1.7f) * 0.8f + 0.2f)
            c.drawPath(path, p)
        }

        // feathers
        p.color = 0xFF10131C.toInt()
        for (i in fx.indices) {
            val prog = (t * 0.9f + fy[i]) % 1f
            val x = w * fx[i] + 18 * d * sin(prog * 9f + i)
            val y = h * prog
            c.save(); c.rotate(prog * 260f + i * 30f, x, y)
            c.drawOval(x - 5 * d, y - 1.6f * d, x + 5 * d, y + 1.6f * d, p); c.restore()
        }

        // logo
        val la = seg(t, 0.66f, 0.82f)
        if (la > 0f) {
            p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            p.letterSpacing = 0.12f; p.textSize = h * 0.10f
            p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * la).toInt()
            c.drawText("ITACHI", cx - w * 0.26f, h * 0.43f, p)
            p.letterSpacing = 0.3f; p.textSize = h * 0.065f; p.color = 0xFFD7263D.toInt(); p.alpha = (255 * la).toInt()
            c.drawText("GAME SPACE", cx - w * 0.26f, h * 0.52f, p)
            p.letterSpacing = 0.15f; p.textSize = h * 0.032f; p.color = 0xFF9AA6BD.toInt(); p.alpha = (200 * la).toInt()
            c.drawText("PLAY SMOOTH · WIN MORE", cx - w * 0.26f, h * 0.58f, p)
        }

        // loading bar
        val bw = w * 0.34f; val by = h * 0.82f
        p.letterSpacing = 0.05f; p.textSize = h * 0.034f; p.color = 0xFF9AA6BD.toInt(); p.alpha = 220
        c.drawText("Optimizing your game experience...", cx, by - h * 0.03f, p)
        p.color = 0xFF1C2438.toInt(); p.alpha = 255
        c.drawRect(cx - bw / 2, by, cx + bw / 2, by + 3 * d, p)
        p.color = 0xFFD7263D.toInt()
        c.drawRect(cx - bw / 2, by, cx - bw / 2 + bw * seg(t, 0.08f, 0.97f), by + 3 * d, p)

        // skip hint
        p.textAlign = Paint.Align.RIGHT; p.letterSpacing = 0.1f; p.textSize = h * 0.032f; p.color = 0xFF9AA6BD.toInt(); p.alpha = 200
        c.drawText("TAP TO SKIP", w - 24 * d, 32 * d, p)
        p.letterSpacing = 0f
    }
}
