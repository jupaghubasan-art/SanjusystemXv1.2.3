package com.sanju.systemx.ui.animations

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * 5 s opening, redrawn in code: black screen with a thin red edge glow → glowing red emblem with ripples →
 * the emblem spins and zooms in → red flash with light streaks → ITACHI GAME SPACE logo and loading bar.
 * One animator value t (0..1) drives everything; it redraws only while that animator runs.
 *
 * Optional: if the project contains a drawable named `intro_image` (your own picture), it is shown dimmed behind the
 * emblem. No image is bundled; add one only if you own the rights to it.
 */
class ItachiIntroView(ctx: Context) : View(ctx) {
    var t = 0f
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(5)
    private val ang = FloatArray(32) { rnd.nextFloat() * 6.2832f }
    private val len = FloatArray(32) { 0.3f + rnd.nextFloat() * 0.7f }
    private var glow: RadialGradient? = null
    private var photo: Bitmap? = null
    private val photoMatrix = Matrix()
    private val d get() = resources.displayMetrics.density

    init {
        val id = resources.getIdentifier("intro_image", "drawable", ctx.packageName)
        if (id != 0) {
            try { photo = BitmapFactory.decodeResource(resources, id, BitmapFactory.Options().apply { inSampleSize = 2 }) }
            catch (e: Throwable) { photo = null }
        }
    }

    private fun seg(v: Float, a: Float, b: Float) = ((v - a) / (b - a)).coerceIn(0f, 1f)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        glow = RadialGradient(0f, 0f, 1f, intArrayOf(0xCCD7263D.toInt(), 0x66D7263D, 0x00D7263D), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        photo?.let {
            val s = max(w / it.width.toFloat(), h / it.height.toFloat())
            photoMatrix.reset(); photoMatrix.postScale(s, s)
            photoMatrix.postTranslate((w - it.width * s) / 2f, (h - it.height * s) / 2f)
        }
    }

    private fun glowAt(c: Canvas, cx: Float, cy: Float, r: Float, a: Float) {
        if (a <= 0f) return
        c.save(); c.translate(cx, cy); c.scale(r, r)
        p.style = Paint.Style.FILL; p.shader = glow; p.alpha = (255 * a).toInt().coerceIn(0, 255)
        c.drawCircle(0f, 0f, 1f, p); c.restore(); p.shader = null
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
        c.drawColor(0xFF000000.toInt())

        // optional user picture, dimmed
        photo?.let {
            val a = seg(t, 0.2f, 0.45f) * (1f - seg(t, 0.8f, 0.95f)) * 0.35f
            if (a > 0f) { p.alpha = (255 * a).toInt(); c.drawBitmap(it, photoMatrix, p); p.alpha = 255 }
        }

        // red edge glow (thin frame)
        val ea = seg(t, 0f, 0.14f)
        if (ea > 0f) {
            p.style = Paint.Style.STROKE; p.color = 0xFFD7263D.toInt()
            for (i in 6 downTo 1) {
                p.strokeWidth = i * 5f * d; p.alpha = (26 * ea).toInt()
                c.drawRect(0f, 0f, w, h, p)
            }
            p.strokeWidth = 2f * d; p.alpha = (200 * ea).toInt(); c.drawRect(1f * d, 1f * d, w - d, h - d, p)
        }

        // emblem phases: appear → spin & zoom → hold small for logo
        val appear = seg(t, 0.08f, 0.28f)
        val zoom = seg(t, 0.30f, 0.60f)
        val zoomE = zoom * zoom
        val small = h * 0.085f
        val big = h * 0.62f
        val settle = seg(t, 0.62f, 0.78f)
        val r = if (t < 0.62f) small + (big - small) * zoomE else big + (h * 0.12f - big) * settle
        val ex = cx
        val ey = cy
        val angle = (zoomE * 720f) + t * 20f

        // ripples around the emblem
        if (appear > 0f && t < 0.62f) {
            for (k in 0 until 3) {
                val ph = ((t * 2.2f) + k / 3f) % 1f
                glowAt(c, ex, ey, r * (1.2f + 1.6f * ph), (1f - ph) * appear * 0.8f)
            }
        }
        glowAt(c, ex, ey, r * 1.9f, appear * (0.5f + 0.5f * zoom))

        // flash + streaks
        val burst = seg(t, 0.52f, 0.62f) * (1f - seg(t, 0.64f, 0.80f))
        val showEmblem = t < 0.66f
        if (appear > 0f && showEmblem) ItachiArt.mangekyo(c, ex, ey, r, angle, p, (255 * appear).toInt())
        if (burst > 0f) {
            p.style = Paint.Style.FILL; p.color = 0xFFD7263D.toInt(); p.alpha = (225 * burst).toInt()
            c.drawRect(0f, 0f, w, h, p)
            p.style = Paint.Style.STROKE; p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * burst).toInt(); p.strokeWidth = 2 * d
            val reach = max(w, h)
            for (i in ang.indices) {
                val l = reach * len[i] * burst
                c.drawLine(cx, cy, cx + cos(ang[i]) * l, cy + sin(ang[i]) * l, p)
            }
        }

        // logo
        val la = seg(t, 0.68f, 0.84f)
        if (la > 0f) {
            val lx = cx + w * 0.10f
            ItachiArt.mangekyo(c, cx - w * 0.24f, cy - h * 0.02f, h * 0.17f, t * 90f, p, (255 * la).toInt())
            p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            p.letterSpacing = 0.12f; p.textSize = h * 0.11f
            p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * la).toInt()
            c.drawText("ITACHI", lx, cy - h * 0.03f, p)
            p.letterSpacing = 0.3f; p.textSize = h * 0.07f; p.color = 0xFFD7263D.toInt(); p.alpha = (255 * la).toInt()
            c.drawText("GAME SPACE", lx, cy + h * 0.08f, p)
            p.letterSpacing = 0.15f; p.textSize = h * 0.032f; p.color = 0xFF9AA6BD.toInt(); p.alpha = (200 * la).toInt()
            c.drawText("PLAY SMOOTH · WIN MORE", lx, cy + h * 0.15f, p)
        }

        // loading bar
        val bw = w * 0.34f; val by = h * 0.86f
        p.style = Paint.Style.FILL; p.typeface = Typeface.DEFAULT; p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.05f; p.textSize = h * 0.032f; p.color = 0xFF9AA6BD.toInt(); p.alpha = (220 * seg(t, 0.05f, 0.2f)).toInt()
        c.drawText("Optimizing your game experience...", cx, by - h * 0.025f, p)
        p.color = 0xFF1C2438.toInt(); p.alpha = 255
        c.drawRect(cx - bw / 2, by, cx + bw / 2, by + 3 * d, p)
        p.color = 0xFFD7263D.toInt()
        c.drawRect(cx - bw / 2, by, cx - bw / 2 + bw * seg(t, 0.05f, 0.97f), by + 3 * d, p)

        p.textAlign = Paint.Align.RIGHT; p.letterSpacing = 0.1f; p.textSize = h * 0.03f; p.color = 0xFF9AA6BD.toInt(); p.alpha = 180
        c.drawText("TAP TO SKIP", w - 24 * d, 32 * d, p)
        p.letterSpacing = 0f
    }
}
