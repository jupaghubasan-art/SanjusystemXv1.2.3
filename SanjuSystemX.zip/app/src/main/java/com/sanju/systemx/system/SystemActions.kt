package com.sanju.systemx.system

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.provider.Settings
import com.sanju.systemx.optimizer.Kind
import com.sanju.systemx.optimizer.Step
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import kotlin.math.abs

enum class DndMode(val title: String, val filter: Int) {
    GAMING("Gaming", NotificationManager.INTERRUPTION_FILTER_PRIORITY),
    STANDARD("Standard", NotificationManager.INTERRUPTION_FILTER_ALL),
    SLEEP("Sleep", NotificationManager.INTERRUPTION_FILTER_ALARMS),
    CUSTOM("Custom", -1)
}

/** Do Not Disturb through Android's notification-policy API. Some calls, alarms and system alerts may still come through. */
object DndManager {
    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    fun hasAccess(c: Context) = nm(c).isNotificationPolicyAccessGranted
    fun openAccessSettings(c: Context) {
        c.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun filterName(f: Int) = when (f) {
        NotificationManager.INTERRUPTION_FILTER_ALL -> "Off (all notifications)"
        NotificationManager.INTERRUPTION_FILTER_PRIORITY -> "Priority only"
        NotificationManager.INTERRUPTION_FILTER_ALARMS -> "Alarms only"
        NotificationManager.INTERRUPTION_FILTER_NONE -> "Total silence"
        else -> "Unknown"
    }

    fun apply(c: Context, p: Prefs, filter: Int): Step {
        if (!hasAccess(c)) return Step(Kind.INFO, "DND skipped: notification-policy access not granted")
        val n = nm(c)
        if (p.getI("dnd_prev", -1) == -1) p.setI("dnd_prev", n.currentInterruptionFilter)
        return try {
            n.setInterruptionFilter(filter)
            if (n.currentInterruptionFilter == filter) Step(Kind.OK, "DND: ${filterName(filter)}")
            else Step(Kind.FAIL, "DND request was overridden by the system")
        } catch (e: Exception) { Step(Kind.FAIL, "DND failed: ${e.javaClass.simpleName}") }
    }

    fun restore(c: Context, p: Prefs): Step? {
        val prev = p.getI("dnd_prev", -1)
        if (prev == -1 || !hasAccess(c)) return null
        nm(c).setInterruptionFilter(prev)
        p.setI("dnd_prev", -1)
        return Step(Kind.OK, "DND restored: ${filterName(prev)}")
    }
}

enum class TouchPreset(val title: String, val ms: Int) { SLOW("SLOW", 800), DEFAULT("DEFAULT", -1), FAST("FAST", 250) }

/**
 * Touch response presets change Android's system touch-and-hold delay (secure setting long_press_timeout).
 * This does NOT raise the screen's touch sampling rate and does not change how MLBB reads touch input.
 */
object TouchPresets {
    suspend fun apply(p: Prefs, preset: TouchPreset): Step {
        if (!p.getB("lp_saved", false)) {
            val g = ShizukuBridge.exec("settings", "get", "secure", "long_press_timeout")
            val v = g.out.trim().let { if (it == "null") 400 else it.toIntOrNull() }
            if (g.code != 0 || v == null) return Step(Kind.FAIL, "Touch preset failed: could not read the current value (${g.out})")
            p.setI("lp_orig", v); p.setB("lp_saved", true)
        }
        val target = if (preset == TouchPreset.DEFAULT) p.getI("lp_orig", 400) else preset.ms
        val r = ShizukuBridge.exec("settings", "put", "secure", "long_press_timeout", target.toString())
        return if (r.code == 0) {
            p.setS("touch", preset.name)
            Step(Kind.OK, "Touch ${preset.title}: touch-and-hold delay $target ms (system setting only)")
        } else Step(Kind.FAIL, "Touch preset failed: ${r.out.ifBlank { "rejected" }}")
    }
}

object GameModeManager {
    suspend fun set(mode: String, pkg: String) = ShizukuBridge.exec("cmd", "game", "mode", mode, pkg)
}

enum class ColorPreset(val title: String, val temp: Int, val dim: Int, val gray: Boolean, val supported: Boolean) {
    NATURAL("Natural", 0, 0, false, true),
    COOL("Cool", -60, 0, false, true),
    WARM("Warm", 60, 0, false, true),
    VIVID("Vivid", 0, 0, false, false),
    CINEMATIC("Cinematic", 25, 15, false, true),
    GRAYSCALE("Grayscale", 0, 0, true, true)
}

/**
 * Colour effects. A full-screen touch-through overlay can tint and dim whatever is on screen; Android does not let a normal
 * app change saturation or contrast of another app. Grayscale uses Android's own colour-correction setting via Shizuku.
 */
object ColorFx {
    fun tintColor(temp: Int, intensity: Int): Int {
        if (temp == 0) return 0
        val a = (abs(temp) / 100f * 0.30f * intensity / 100f * 255).toInt().coerceIn(0, 90)
        return if (temp > 0) Color.argb(a, 255, 150, 60) else Color.argb(a, 70, 140, 255)
    }

    fun dimColor(dim: Int): Int = Color.argb((dim.coerceIn(0, 45) / 100f * 0.5f * 255).toInt(), 0, 0, 0)

    suspend fun setGray(p: Prefs, on: Boolean): Step {
        if (on) {
            val a = ShizukuBridge.exec("settings", "put", "secure", "accessibility_display_daltonizer", "0")
            val b = ShizukuBridge.exec("settings", "put", "secure", "accessibility_display_daltonizer_enabled", "1")
            if (a.code != 0 || b.code != 0) return Step(Kind.FAIL, "Grayscale failed: ${(a.out + " " + b.out).trim()}")
        } else {
            val b = ShizukuBridge.exec("settings", "put", "secure", "accessibility_display_daltonizer_enabled", "0")
            if (b.code != 0) return Step(Kind.FAIL, "Grayscale off failed: ${b.out}")
        }
        p.setB("fx_gray", on)
        return Step(Kind.OK, "Grayscale ${if (on) "on" else "off"} (Android colour correction)")
    }
}
