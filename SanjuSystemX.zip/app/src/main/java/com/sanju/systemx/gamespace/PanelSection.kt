package com.sanju.systemx.gamespace

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import com.sanju.systemx.overlay.OverlayService
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.system.DndManager
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import com.sanju.systemx.ui.switchRow

private val ipRx = Regex("^(\\d{1,3})(\\.\\d{1,3}){3}$")

/** PANEL: floating in-game panel settings and the permissions it needs, each explained. */
fun GameSpaceActivity.panelSection(): View {
    val act = this
    val canOverlay = Settings.canDrawOverlays(this)
    val running = OverlayService.running()
    val needNotif = Build.VERSION.SDK_INT >= 33 &&
        checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    root.weight(left, 1f); root.weight(right, 1f, dp(12))
    val out = label("", 11f, Pal.sub)

    left.put(box("FLOATING PANEL").apply {
        put(label(if (running) "● PANEL ACTIVE" else "○ PANEL STOPPED", 13f, if (running) Pal.GREEN else Pal.sub, true), 4)
        put(btn(if (running) "STOP PANEL" else "START PANEL") {
            if (!canOverlay) { out.text = "✕ Grant 'display over other apps' first (right side)."; return@btn }
            if (running) OverlayService.stop(act) else OverlayService.start(act)
            window.decorView.postDelayed({ renderSection() }, 400)
        }, 8)
        put(slider("Panel opacity %", 40, 100, prefs.getI("panel_alpha", 85)) {
            prefs.setI("panel_alpha", it); OverlayService.refreshOpacity()
        }, 8)
        put(switchRow("Start panel with BOOST & PLAY / LAUNCH", prefs.getB("panel_auto", true)) { prefs.setB("panel_auto", it) }, 6)
        put(switchRow("Restore settings when the panel is closed", prefs.getB("restore_on_close", true)) { prefs.setB("restore_on_close", it) }, 2)
        put(label("Tap the bubble to open the panel. Drag the header to move it. – minimizes, ✕ closes.", 10f, Pal.sub), 6)
        put(out, 6)
    }, 0)

    val host = EditText(this).apply {
        setText(prefs.getS("ping_host", "1.1.1.1")); setTextColor(Pal.text); textSize = 13f
        inputType = InputType.TYPE_CLASS_PHONE; contentDescription = "Ping host IPv4"
    }
    left.put(box("PING (OPTIONAL)").apply {
        put(label("Ping is a one-time test you start from the panel. It sends one ICMP packet to this IPv4 address through Shizuku. No background traffic.", 10f, Pal.sub), 4)
        put(host, 4)
        put(btn("SAVE HOST", false) {
            val v = host.text.toString().trim()
            if (ipRx.matches(v) && v.split(".").all { it.toInt() in 0..255 }) { prefs.setS("ping_host", v); out.text = "✓ Ping host saved" }
            else out.text = "✕ Enter a valid IPv4 address"
        }, 6)
    })

    right.put(box("PERMISSIONS (EACH EXPLAINED)").apply {
        put(label((if (canOverlay) "✓" else "✕") + " Display over other apps: needed to draw the panel and colour filter over the game.", 11f, if (canOverlay) Pal.GREEN else AMBER, true), 4)
        if (!canOverlay) put(btn("GRANT OVERLAY PERMISSION", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, 4)
        put(label((if (!needNotif) "✓" else "ℹ") + " Notifications: Android shows a small 'panel active' notice while the panel runs.", 11f, if (!needNotif) Pal.GREEN else AMBER, true), 6)
        if (needNotif) put(btn("ALLOW NOTIFICATION", false) { requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 77) }, 4)
        put(label((if (DndManager.hasAccess(act)) "✓" else "ℹ") + " Do Not Disturb access: optional, needed only for the DND controls.", 11f, if (DndManager.hasAccess(act)) Pal.GREEN else AMBER, true), 6)
        if (!DndManager.hasAccess(act)) put(btn("GRANT DND ACCESS", false) { DndManager.openAccessSettings(act) }, 4)
        put(label((if (vm.shizuku.value == ShizukuState.CONNECTED) "✓" else "ℹ") + " Shizuku: needed for live game FPS, CPU usage, Game Mode, touch presets, grayscale and resolution.", 11f,
            if (vm.shizuku.value == ShizukuState.CONNECTED) Pal.GREEN else AMBER, true), 6)
    }, 0)
    right.put(box("WHAT THE PANEL SHOWS").apply {
        put(label("FPS (measured from the game's own surface, source shown), refresh Hz, battery temperature, CPU %, FPS graph and session min/avg/max. Values the phone does not expose show N/A. Updates every 2 s only while expanded.", 11f, Pal.sub), 4)
    })
    return root
}
