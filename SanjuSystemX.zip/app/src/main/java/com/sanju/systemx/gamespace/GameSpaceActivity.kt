package com.sanju.systemx.gamespace

import android.animation.Animator
import android.animation.ValueAnimator
import android.content.pm.ActivityInfo
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.R
import com.sanju.systemx.audio.SoundFx
import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.optimizer.OptimizationEngine
import com.sanju.systemx.optimizer.OptimizationProfile
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.animations.ItachiIntroView
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.ItachiBackground
import com.sanju.systemx.ui.components.MATCH
import com.sanju.systemx.ui.components.WRAP
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.components.smallBtn
import com.sanju.systemx.ui.components.tag
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** GAME SPACE shell: boot intro, hub background, top/bottom status bars, landscape rail and the five sections. */
class GameSpaceActivity : AppCompatActivity() {

    enum class Section(val titleRes: Int, val icon: Int) {
        HOME(R.string.nav_home, android.R.drawable.ic_menu_compass),
        GAMES(R.string.nav_games, android.R.drawable.ic_menu_gallery),
        PERFORMANCE(R.string.nav_performance, android.R.drawable.ic_menu_rotate),
        EFFECTS(R.string.nav_effects, android.R.drawable.ic_menu_slideshow),
        PANEL(R.string.nav_panel, android.R.drawable.ic_menu_agenda),
        MONITOR(R.string.nav_monitor, android.R.drawable.ic_menu_view),
        SETTINGS(R.string.nav_settings, android.R.drawable.ic_menu_preferences)
    }

    lateinit var prefs: Prefs
    lateinit var vm: GameSpaceViewModel
    lateinit var monitor: Monitor
    lateinit var engine: OptimizationEngine
    lateinit var sfx: SoundFx
    lateinit var rootFrame: FrameLayout
    lateinit var body: FrameLayout
    private lateinit var shell: LinearLayout
    private val railItems = LinkedHashMap<Section, LinearLayout>()
    private lateinit var tGpu: TextView
    private lateinit var tTemp: TextView
    private lateinit var tBat: TextView
    private lateinit var tShizuku: TextView
    private lateinit var tOnline: TextView
    private lateinit var bShizuku: TextView
    private lateinit var bReady: TextView
    private lateinit var bProfile: TextView
    private lateinit var bConnect: View

    var section = Section.HOME
    var liveUpdater: ((Monitor.Sample) -> Unit)? = null
    var probeAnim: Animator? = null
    private var pollJob: Job? = null
    var extraJob: Job? = null
    lateinit var bgView: ItachiBackground
    private var ready = false
    private var wasStopped = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        Pal.dark = prefs.getB("dark", true)
        Pal.haptic = prefs.getB("haptic", true)
        Pal.anim = prefs.getB("anim", true)
        requestedOrientation = if (prefs.getB("autoLandscape", true)) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        vm = ViewModelProvider(this)[GameSpaceViewModel::class.java]
        monitor = Monitor(this)
        engine = OptimizationEngine(this, prefs)
        sfx = SoundFx(this).also { it.enabled = prefs.getB("sound", true) }
        section = Section.values().getOrElse(savedInstanceState?.getInt("section", 0) ?: 0) { Section.HOME }
        if (prefs.getB("awake", false)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val mode = prefs.getI("mode", 0)
        if (mode != 0) DisplayCtl.apply(this, mode)
        setupWindow()

        rootFrame = FrameLayout(this)
        bgView = ItachiBackground(this).apply { this.mode = prefs.getI("bgmode", 1) }
        rootFrame.addView(bgView, MATCH, MATCH)
        shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(topBar(), lp(MATCH, WRAP))
        val mid = LinearLayout(this)
        mid.addView(railView(), lp(WRAP, MATCH))
        body = FrameLayout(this)
        mid.addView(body, lp(0, MATCH, 1f))
        shell.addView(mid, lp(MATCH, 0, 1f))
        shell.addView(bottomBar(), lp(MATCH, WRAP))
        rootFrame.addView(shell, MATCH, MATCH)
        setContentView(rootFrame)
        ViewCompat.setOnApplyWindowInsetsListener(rootFrame) { _, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            shell.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        applyVisual(prefs.getB("anime", false))
        refreshRail()
        observeState()
        startBoot()
    }

    private fun setupWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val ic = WindowCompat.getInsetsController(window, window.decorView)
        ic.hide(WindowInsetsCompat.Type.systemBars())
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (Build.VERSION.SDK_INT >= 28) {
            val a = window.attributes
            a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = a
        }
    }

    // ───────── boot: intro + data load, then reveal ─────────
    private fun startBoot() {
        val showIntro = !vm.introDone && prefs.getB("intro", true)
        shell.visibility = if (showIntro) View.INVISIBLE else View.VISIBLE
        var introOk = !showIntro
        var dataOk = false
        var intro: ItachiIntroView? = null

        fun reveal() {
            if (!introOk || !dataOk || ready) return
            ready = true
            vm.introDone = true
            intro?.let { v -> v.animate().alpha(0f).setDuration(250).withEndAction { rootFrame.removeView(v) }.start() }
            shell.visibility = View.VISIBLE
            if (showIntro) { shell.alpha = 0f; shell.animate().alpha(1f).setDuration(300).start() }
            sfx.play(com.sanju.systemx.R.raw.sfx_ready, 0.6f)
            updateStatusBars()
            renderSection()
        }

        if (showIntro) {
            val v = ItachiIntroView(this)
            intro = v
            rootFrame.addView(v, MATCH, MATCH)
            val an = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 5000
                interpolator = LinearInterpolator()
                addUpdateListener { v.t = it.animatedValue as Float }
            }
            an.doOnEnd { introOk = true; reveal() }
            v.setOnClickListener { an.end() }
            sfx.play(R.raw.sfx_whoosh, 0.7f)
            v.postDelayed({ sfx.play(R.raw.sfx_boom, 0.8f) }, 2900)
            an.start()
        }
        lifecycleScope.launch {
            if (!vm.introDone) vm.load(applicationContext, prefs)
            dataOk = true
            reveal()
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.shizuku.drop(1).collect { updateStatusBars(); if (ready && (section == Section.HOME || section == Section.PERFORMANCE)) renderSection() } }
                launch { vm.selected.drop(1).collect { updateStatusBars(); if (ready && section == Section.HOME) renderSection() } }
                launch { vm.games.drop(1).collect { if (ready && (section == Section.HOME || section == Section.GAMES)) renderSection() } }
                launch { vm.graphics.drop(1).collect { updateStatusBars() } }
            }
        }
    }

    // ───────── chrome ─────────
    private fun topBar(): View {
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xCC121827.toInt())
            setPadding(dp(14), dp(5), dp(14), dp(5))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("ITACHI GAME SPACE", 15f, Pal.RED, true).apply { letterSpacing = 0.1f })
        brand.addView(label(getString(R.string.gs_title), 10f, Pal.sub, true).apply { letterSpacing = 0.3f })
        bar.addView(brand, lp(WRAP, WRAP))
        val strip = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val tCpu = tag("CPU ${Runtime.getRuntime().availableProcessors()} CORES")
        tGpu = tag("GPU …"); tTemp = tag("TEMP …"); tBat = tag("BAT …"); tShizuku = tag("SHIZUKU …"); tOnline = tag("● ONLINE", Pal.GREEN)
        listOf(tCpu, tGpu, tTemp, tBat, tShizuku, tOnline).forEach { strip.addView(it, lp(WRAP, WRAP).apply { marginStart = dp(6) }) }
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) }
        bar.addView(hs, lp(0, WRAP, 1f).apply { marginStart = dp(12) })
        return bar
    }

    private fun bottomBar(): View {
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xCC121827.toInt())
            setPadding(dp(14), dp(3), dp(14), dp(3))
        }
        bShizuku = label("SHIZUKU …", 11f, Pal.sub, true)
        bConnect = smallBtn("CONNECT / CHECK SHIZUKU") { checkShizuku() }.apply { textSize = 10f; minimumHeight = dp(30); minHeight = dp(30) }
        bReady = label("GAME SPACE READY", 11f, Pal.GREEN, true).apply { gravity = Gravity.CENTER }
        bProfile = label("", 11f, Pal.text, true).apply { gravity = Gravity.END }
        bar.addView(bShizuku, lp(WRAP, WRAP))
        bar.addView(bConnect, lp(WRAP, dp(30)).apply { marginStart = dp(8) })
        bar.addView(bReady, lp(0, WRAP, 1f))
        bar.addView(bProfile, lp(WRAP, WRAP))
        return bar
    }

    private fun railView(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        Section.values().forEach { s ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(6), dp(4), dp(6))
                isClickable = true
                contentDescription = getString(s.titleRes)
                setOnClickListener { click(); select(s) }
            }
            item.addView(ImageView(this).apply { setImageResource(s.icon) }, lp(dp(22), dp(22)))
            item.addView(label(getString(s.titleRes).uppercase(), 9f, Pal.sub, true).apply { gravity = Gravity.CENTER })
            railItems[s] = item
            col.addView(item, lp(dp(78), WRAP).apply { bottomMargin = dp(3) })
        }
        return ScrollView(this).apply {
            setBackgroundColor(0xB3121827.toInt())
            isVerticalScrollBarEnabled = false
            addView(col)
        }
    }

    private fun refreshRail() {
        railItems.forEach { (s, item) ->
            val on = s == section
            item.background = if (on) GradientDrawable().apply {
                setColor(0x33D7263D); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Pal.RED)
            } else null
            (item.getChildAt(0) as ImageView).setColorFilter(if (on) Pal.RED else Pal.sub)
            (item.getChildAt(1) as TextView).setTextColor(if (on) Pal.RED else Pal.sub)
        }
    }

    fun updateStatusBars() {
        if (!::tShizuku.isInitialized) return
        val (txt, col) = when (vm.shizuku.value) {
            ShizukuState.CONNECTED -> getString(R.string.shizuku_connected) to Pal.GREEN
            null -> "NOT CHECKED" to Pal.sub
            else -> getString(R.string.shizuku_not_connected) to AMBER
        }
        tShizuku.text = "SHIZUKU ● $txt"; tShizuku.setTextColor(col)
        bShizuku.text = "SHIZUKU ● $txt"; bShizuku.setTextColor(col)
        bConnect.visibility = if (vm.shizuku.value == ShizukuState.CONNECTED) View.GONE else View.VISIBLE
        tGpu.text = "GPU ${vm.graphics.value?.gpuShort ?: "…"}"
        val healthy = vm.healthy
        tOnline.text = if (healthy) "● ONLINE" else "● DEGRADED"
        tOnline.setTextColor(if (healthy) Pal.GREEN else AMBER)
        bReady.text = if (healthy) "GAME SPACE READY" else "GAME SPACE LIMITED"
        bReady.setTextColor(if (healthy) Pal.GREEN else AMBER)
        bProfile.text = "PROFILE ${OptimizationProfile.fromName(prefs.getS("profile", "BALANCED")).title}"
    }

    private fun updateTop(s: Monitor.Sample) {
        tTemp.text = "TEMP " + (s.tempC?.let { "${Math.round(it)}°C" } ?: "N/A")
        tBat.text = "BAT " + (if (s.battery >= 0) "${s.battery}%" else "N/A") + (if (s.charging) " ⚡" else "")
    }

    // ───────── sections ─────────
    fun select(s: Section) {
        section = s
        refreshRail()
        renderSection()
    }

    fun renderSection() {
        if (!ready) return
        stopLive()
        liveUpdater = null
        body.removeAllViews()
        val v: View = when (section) {
            Section.HOME -> homeSection()
            Section.GAMES -> gamesSection()
            Section.PERFORMANCE -> performanceSection()
            Section.EFFECTS -> effectsSection()
            Section.PANEL -> panelSection()
            Section.MONITOR -> monitorSection()
            Section.SETTINGS -> settingsSection()
        }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(v) }
        body.addView(sv)
        if (Pal.anim) {
            sv.alpha = 0f; sv.translationY = dp(10).toFloat()
            sv.animate().alpha(1f).translationY(0f).setDuration(220).start()
        }
        startPoll()
    }

    /** Lifecycle-bound polling: stops when the screen is left or the app goes to the background. */
    private fun startPoll() {
        val every = if (section == Section.MONITOR) 1000L else 3000L
        pollJob = lifecycleScope.launch {
            while (isActive) {
                val s = monitor.sample()
                updateTop(s)
                liveUpdater?.invoke(s)
                delay(every)
            }
        }
    }

    fun stopLive() {
        pollJob?.cancel(); pollJob = null
        extraJob?.cancel(); extraJob = null
        probeAnim?.cancel(); probeAnim = null
        monitor.stop()
    }

    // ───────── helpers used by sections ─────────
    fun click() { sfx.play(R.raw.sfx_click, 0.5f) }
    fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    fun checkShizuku() {
        lifecycleScope.launch {
            var st = ShizukuBridge.state(this@GameSpaceActivity)
            vm.shizuku.value = st
            if (st == ShizukuState.NEEDS_PERMISSION) {
                ShizukuBridge.requestPermission()
                for (i in 0 until 30) {
                    delay(500)
                    st = ShizukuBridge.state(this@GameSpaceActivity)
                    vm.shizuku.value = st
                    if (st == ShizukuState.CONNECTED) break
                }
            }
            when (st) {
                ShizukuState.NOT_INSTALLED -> toast("Shizuku is not installed.")
                ShizukuState.NOT_RUNNING -> toast("Start Shizuku first (Wireless debugging), then tap again.")
                else -> {}
            }
            GsLog.d("Shizuku", "state=$st")
        }
    }

    suspend fun ask(title: String, msg: String, ok: String): Boolean = suspendCancellableCoroutine { c ->
        val d = AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton(ok) { _, _ -> if (c.isActive) c.resume(true) }
            .setNegativeButton("CANCEL") { _, _ -> if (c.isActive) c.resume(false) }
            .setOnCancelListener { if (c.isActive) c.resume(false) }
            .create()
        c.invokeOnCancellation { d.dismiss() }
        d.show()
    }

    /** Visual-only filter for the Game Space UI. It never touches any game. */
    fun applyVisual(on: Boolean) {
        if (!on) { rootFrame.setLayerType(View.LAYER_TYPE_NONE, null); return }
        val cm = ColorMatrix().apply { setSaturation(1.45f) }
        val c = 1.12f
        val t = (-0.5f * c + 0.5f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        rootFrame.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
    }

    // ───────── lifecycle ─────────
    override fun onResume() {
        super.onResume()
        bgView.running = true
        if (!ready) return
        if (wasStopped) {
            wasStopped = false
            lifecycleScope.launch {
                val msg = GameSessionManager.end(prefs, monitor.sample())
                if (msg != null) { vm.lastSession = msg; renderSection() }
            }
        }
        updateStatusBars()
        renderSection()
    }

    override fun onPause() { bgView.running = false; stopLive(); super.onPause() }
    override fun onStop() { wasStopped = true; super.onStop() }
    override fun onDestroy() { stopLive(); sfx.release(); super.onDestroy() }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("section", section.ordinal)
    }
}
