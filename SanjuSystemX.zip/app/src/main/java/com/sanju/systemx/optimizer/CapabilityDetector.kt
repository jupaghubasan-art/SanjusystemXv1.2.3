package com.sanju.systemx.optimizer

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.Settings
import com.sanju.systemx.device.GraphicsInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.system.DndManager
import java.io.File

enum class Support { SUPPORTED, LIMITED, UNSUPPORTED }
data class Capability(val name: String, val support: Support, val note: String)

object CapabilityDetector {
    fun detect(a: Activity, sz: ShizukuState?, gfx: GraphicsInfo?): List<Capability> {
        val rates = DisplayCtl.rates(a)
        val sh = sz == ShizukuState.CONNECTED
        val b: Intent? = a.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val hasTemp = b?.hasExtra(BatteryManager.EXTRA_TEMPERATURE) == true
        val hasFreq = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").runCatching { readText(); true }.getOrDefault(false)
        val needSh = "Needs Shizuku connected"
        return listOf(
            Capability("Display refresh rate (request)", if (rates.size > 1) Support.LIMITED else Support.UNSUPPORTED,
                if (rates.size > 1) "${rates.joinToString(" / ") { it.hz.toString() }} Hz; applies to this app's window, system may override" else "Display reports a single rate"),
            Capability("Game FPS limit (30/45/60/90/120)", Support.UNSUPPORTED, "MLBB controls its own FPS; set it inside the game"),
            Capability("Live game FPS", if (sh) Support.LIMITED else Support.UNSUPPORTED,
                if (sh) "SurfaceFlinger timestamps via Shizuku; may be unavailable on some Android builds" else needSh),
            Capability("CPU usage", if (sh) Support.SUPPORTED else Support.UNSUPPORTED, if (sh) "/proc/stat via Shizuku" else needSh),
            Capability("GPU utilization", if (sh) Support.LIMITED else Support.UNSUPPORTED, if (sh) "MediaTek GED node, only if the device exposes it" else needSh),
            Capability("CPU frequency", if (hasFreq) Support.LIMITED else Support.UNSUPPORTED, if (hasFreq) "Readable on this device" else "Restricted by Android"),
            Capability("Thermal status / battery temp", if (hasTemp) Support.SUPPORTED else Support.LIMITED, "Public APIs; battery sensor is not CPU temperature"),
            Capability("Resolution scaling", if (sh) Support.SUPPORTED else Support.UNSUPPORTED, if (sh) "wm size via Shizuku, with confirmation" else needSh),
            Capability("Android Game Mode", if (sh) Support.LIMITED else Support.UNSUPPORTED, if (sh) "cmd game mode; effect depends on game/OEM" else needSh),
            Capability("Touch response presets", if (sh) Support.LIMITED else Support.UNSUPPORTED, "System touch-and-hold delay only, not sampling rate"),
            Capability("Do Not Disturb", if (DndManager.hasAccess(a)) Support.SUPPORTED else Support.LIMITED, if (DndManager.hasAccess(a)) "Notification policy access granted" else "Grant notification-policy access"),
            Capability("Floating panel over the game", if (Settings.canDrawOverlays(a)) Support.SUPPORTED else Support.LIMITED, if (Settings.canDrawOverlays(a)) "Overlay permission granted" else "Grant 'display over other apps'"),
            Capability("Game colour (tint / dim)", if (Settings.canDrawOverlays(a)) Support.SUPPORTED else Support.LIMITED, "Touch-through overlay; no saturation or contrast control"),
            Capability("Grayscale", if (sh) Support.SUPPORTED else Support.UNSUPPORTED, if (sh) "Android colour correction via Shizuku" else needSh),
            Capability("Screenshot / screen-record shortcuts", Support.UNSUPPORTED, "Not available to normal apps without extra access"),
            Capability("GPU & graphics info", if (gfx?.renderer != null) Support.SUPPORTED else Support.LIMITED, gfx?.renderer ?: "Renderer not readable")
        )
    }
}
