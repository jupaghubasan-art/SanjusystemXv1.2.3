package com.sanju.systemx.gamespace

import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.R
import com.sanju.systemx.optimizer.OptimizationProfile
import com.sanju.systemx.monitor.ThermalInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.MATCH
import com.sanju.systemx.ui.components.SkewCardDrawable
import com.sanju.systemx.ui.components.StatRow
import com.sanju.systemx.ui.components.WRAP
import com.sanju.systemx.ui.components.iconOf
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.components.smallBtn
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import kotlinx.coroutines.launch
import java.util.Locale

/** HOME: game card + launch, shortcuts, and a real performance summary. (The floating panel is a separate stage.) */
fun GameSpaceActivity.homeSection(): View {
    val act = this
    val g = vm.selectedGame()
    val profile = OptimizationProfile.fromName(prefs.getS("profile", "BALANCED"))
    val connected = vm.shizuku.value == ShizukuState.CONNECTED
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    val card = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(34), dp(16), dp(34), dp(14))
        background = SkewCardDrawable(g != null)
    }
    if (g == null) {
        card.addView(label("NO GAME SELECTED", 16f, Pal.text, true))
        card.addView(label(getString(R.string.select_game_hint), 12f, Pal.sub))
        card.addView(smallBtn("SELECT GAME") { select(GameSpaceActivity.Section.GAMES) }, lp(WRAP, WRAP).apply { topMargin = dp(8) })
    } else {
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageDrawable(iconOf(g.pkg)); contentDescription = g.label }, lp(dp(60), dp(60)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        info.addView(label(g.label.uppercase(), 16f, Pal.text, true))
        info.addView(label(g.pkg, 11f, Pal.sub))
        info.addView(label("STATUS  READY", 12f, Pal.GREEN, true))
        info.addView(label("MODE  ${profile.title}", 12f, Pal.text))
        head.addView(info, lp(0, WRAP, 1f))
        card.addView(head)
        val btns = LinearLayout(this)
        btns.addView(smallBtn("LAUNCH GAME") { launchGame(g) }, lp(0, WRAP, 1f))
        btns.addView(smallBtn("SELECT") { select(GameSpaceActivity.Section.GAMES) }, lp(0, WRAP, 1f).apply { marginStart = dp(6) })
        card.addView(btns, lp(MATCH, WRAP).apply { topMargin = dp(10) })
    }
    left.addView(card, lp(MATCH, WRAP))

    val boost = btn(getString(R.string.boost_play)) { v -> pressAnim(v); startBoost(true) }
        .apply { textSize = 16f; minimumHeight = dp(54); contentDescription = getString(R.string.boost_play) }
    left.put(boost, 10)

    val quick = LinearLayout(this)
    listOf("EFFECTS" to GameSpaceActivity.Section.EFFECTS, "TOUCH" to GameSpaceActivity.Section.PERFORMANCE,
        "PANEL" to GameSpaceActivity.Section.PANEL, "SETTINGS" to GameSpaceActivity.Section.SETTINGS).forEach { (t, s) ->
        quick.addView(smallBtn(t) { click(); select(s) }, lp(0, WRAP, 1f).apply { marginEnd = dp(4) })
    }
    left.put(quick, 8)

    if (prefs.getB("res_modified", false)) {
        val warn = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        warn.addView(label("⚠ RESOLUTION MODIFIED", 12f, AMBER, true), lp(0, WRAP, 1f))
        warn.addView(smallBtn("RESET") {
            act.lifecycleScope.launch {
                if (ask("Reset resolution?", "Shizuku will run:\nwm size reset", "RESET")) {
                    val r = ResolutionManager.reset(prefs)
                    toast(if (r.code == 0) "Native resolution restored." else "Reset failed: ${r.out}")
                    renderSection()
                }
            }
        }, lp(WRAP, WRAP))
        left.addView(warn, lp(MATCH, WRAP))
    }
    if (!connected) {
        left.put(box("SETUP · SHIZUKU REQUIRED").apply {
            put(label("Live game FPS, CPU/GPU usage, Game Mode, touch presets, grayscale and resolution need Shizuku. The app still opens in limited mode.", 11f, Pal.sub), 4)
            put(smallBtn("CONNECT / CHECK SHIZUKU") { checkShizuku() }, 6)
        }, 8)
    }
    vm.lastSession?.let { left.put(label("LAST SESSION  $it", 11f, Pal.sub), 8) }

    val rows = LinkedHashMap<String, StatRow>()
    val panel = box("PERFORMANCE SUMMARY")
    fun row(k: String, init: String) { val r = StatRow(act, k, init); rows[k] = r; panel.addView(r.view) }
    row("REFRESH RATE", "${DisplayCtl.hz(this)} Hz")
    row("SYSTEM RAM", "…")
    row("BATTERY TEMP", "…")
    row("THERMAL STATUS", ThermalInfo.status(this))
    row("SHIZUKU", if (connected) "CONNECTED" else "NOT CONNECTED")
    row("MODE", profile.title)
    row("GRAPHICS API", vm.graphics.value?.apiSummary ?: "Loading…")
    panel.put(label("LAST GAME FPS  " + prefs.getS("last_fps", "none yet · open the floating panel while playing"), 10f, Pal.sub), 6)
    panel.put(label("Display Hz is not game FPS. Game FPS is measured only in the floating panel (Shizuku).", 10f, Pal.sub), 4)

    liveUpdater = { s ->
        rows.getValue("REFRESH RATE").value.text = "${DisplayCtl.hz(act)} Hz"
        rows.getValue("SYSTEM RAM").value.text = s.ramText
        rows.getValue("BATTERY TEMP").value.text = s.tempC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "Unavailable"
        rows.getValue("THERMAL STATUS").value.text = ThermalInfo.status(act)
    }

    root.weight(left, 1.1f)
    root.weight(panel, 1f, dp(12))
    return root
}
