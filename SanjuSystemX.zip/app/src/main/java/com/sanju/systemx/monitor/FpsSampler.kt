package com.sanju.systemx.monitor

import com.sanju.systemx.shizuku.ShizukuBridge

/**
 * Real frame-rate of the game's own surface, read from SurfaceFlinger frame timestamps through Shizuku.
 * Source label is always returned. If Android does not provide timestamps, FPS is null (never invented).
 */
class FpsSampler {
    data class Reading(val fps: Float?, val source: String)

    private var layer: String? = null
    val history = ArrayDeque<Float>()
    var min = Float.MAX_VALUE; private set
    var max = 0f; private set
    private var sum = 0.0
    private var count = 0
    val avg: Float get() = if (count == 0) 0f else (sum / count).toFloat()
    val hasData: Boolean get() = count > 0

    fun reset() { history.clear(); min = Float.MAX_VALUE; max = 0f; sum = 0.0; count = 0 }

    fun summary(): String =
        if (!hasData) "No FPS data" else "FPS min ${Math.round(min)} · avg ${Math.round(avg)} · max ${Math.round(max)} (SurfaceFlinger)"

    suspend fun sample(pkg: String): Reading {
        val src = "SurfaceFlinger latency (Shizuku)"
        var l = layer
        if (l == null) { l = findLayer(pkg); layer = l }
        if (l == null) return Reading(null, "Game surface not found. Is the game in front?")
        val r = ShizukuBridge.exec("dumpsys", "SurfaceFlinger", "--latency", l)
        val fps = if (r.code == 0) parse(r.out) else null
        if (fps == null) { layer = null; return Reading(null, "Frame timestamps unavailable on this Android build") }
        record(fps)
        return Reading(fps, src)
    }

    private suspend fun findLayer(pkg: String): String? {
        val r = ShizukuBridge.exec("dumpsys", "SurfaceFlinger", "--list")
        if (r.code != 0) return null
        val c = r.out.lines().map { it.trim() }.filter {
            it.contains(pkg) && !it.startsWith("Background") && !it.startsWith("Bounds")
        }
        return c.firstOrNull { it.startsWith("SurfaceView") } ?: c.firstOrNull()
    }

    private fun parse(out: String): Float? {
        val lines = out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size < 3) return null
        val times = lines.drop(1).mapNotNull { l ->
            val p = l.split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0L && it != Long.MAX_VALUE }
        if (times.size < 2) return null
        val last = times.max()
        val win = times.filter { it >= last - 1_000_000_000L }.sorted()
        if (win.size < 2) return win.size.toFloat()
        val span = (win.last() - win.first()) / 1e9f
        return if (span < 0.5f) win.size.toFloat() else (win.size - 1) / span
    }

    private fun record(f: Float) {
        if (history.size >= 60) history.removeFirst()
        history.addLast(f)
        if (f < min) min = f
        if (f > max) max = f
        sum += f; count++
    }
}
